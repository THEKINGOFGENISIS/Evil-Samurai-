# Shadow API Hub

A dark red, mobile-friendly dashboard and private REST API for storing text, scripts, JSON, and configuration data. FastAPI + SQLAlchemy + SQLite locally or PostgreSQL in production.

## Features

- Private endpoints protected by `X-API-Key` using constant-time comparison.
- Create, list/search, read, update, and delete records.
- Upload/download/delete arbitrary file types (including source code in different programming languages), stored in the database; 10 MiB per file.
- Persistent relational database (SQLite locally; PostgreSQL recommended for hosted deployment).
- Responsive dashboard at `/`.
- OpenAPI docs at `/docs`.
- Python and Roblox Luau examples in `examples/`.

## API endpoints

All `/v1/items` endpoints require `X-API-Key: YOUR_SECRET_KEY`.

| Method | Path | Purpose |
|---|---|---|
| GET | `/health` | Health check; no key required |
| GET | `/v1/items?limit=50&offset=0&q=config` | List/search records |
| POST | `/v1/items` | Create record |
| GET | `/v1/items/{id}` | Read record |
| PUT | `/v1/items/{id}` | Update record |
| DELETE | `/v1/items/{id}` | Delete record |
| POST | `/v1/files` | Upload a file using multipart field `file` (max 10 MiB) |
| GET | `/v1/files` | List uploaded files |
| GET | `/v1/files/{id}/download` | Download a file |
| DELETE | `/v1/files/{id}` | Delete uploaded file |

### File upload

Use `multipart/form-data` with the field name `file`:

```bash
curl -X POST "$SHADOW_API_URL/v1/files" \\
  -H "X-API-Key: $SHADOW_API_KEY" \\
  -F "file=@./example.py"
```

Files of different extensions/languages are stored as binary data and can be downloaded through the authenticated download endpoint. The starter limit is 10 MiB per file. Since file bytes are stored in PostgreSQL, check your database provider's storage limits before uploading many or large files.

Create body:

```json
{"name":"my-config","content_type":"json","content":"{\"enabled\":true}"}
```

`name` must be unique. `content` is a string (up to 1 MB); for JSON records, the dashboard validates JSON before saving.

## Run locally

Requires Python 3.10+.

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

Set a key before starting. Use a long random secret and keep it private.

```bash
# macOS/Linux
export MASTER_API_KEY='replace-with-a-long-random-secret'
# Windows PowerShell
$env:MASTER_API_KEY='replace-with-a-long-random-secret'
uvicorn main:app --reload
```

Open `http://127.0.0.1:8000`. Enter the base URL and the same key in the dashboard. API docs: `http://127.0.0.1:8000/docs`.

The local default key `dev-only-change-this-key` exists only to make first-time local startup easy. **Never use it in production.** Always set `MASTER_API_KEY` on the host.

## Free deployment (Render + PostgreSQL)

Free-tier details, availability, sleeping, storage, and limits can change. Check the providers' current plans before deploying. Do not use ephemeral local SQLite for hosted production data: many free web hosts discard local files on redeploy/restart.

1. Push this folder to a private or public GitHub repository. Do not commit `.env` or real API keys.
2. Create a PostgreSQL database with a provider that offers a free tier, for example Supabase or Neon. Copy its PostgreSQL connection string. If the provider gives a pooled connection string, use its recommended URL for application connections.
3. Create a new Web Service on Render and connect the repository.
4. Build command: `pip install -r requirements.txt`
5. Start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
6. Add environment variables in the host dashboard:
   - `DATABASE_URL` = PostgreSQL connection URL from your database provider.
   - `MASTER_API_KEY` = a long, randomly generated secret. Example generation: `python -c "import secrets; print(secrets.token_urlsafe(40))"`; generate it locally and keep it private.
7. Deploy. Visit `https://YOUR-SERVICE.onrender.com/health` and confirm `{"status":"ok","service":"Shadow API Hub"}`.
8. Open the root URL, paste the root URL into **API base URL**, paste the exact secret into **API Key**, and click **Kết nối & tải dữ liệu**.
9. Test `/docs` and create a sample record.

If your PostgreSQL provider requires SSL, use its full connection URL with SSL parameters as documented by that provider. The code converts `postgres://` to `postgresql://` when necessary.

## Python example

Install `requests` (`pip install requests`) and set environment variables:

```bash
export SHADOW_API_URL='https://YOUR-SERVICE.onrender.com'
export SHADOW_API_KEY='your-secret'
python examples/python_client.py
```

## Roblox Luau example

See `examples/luau_client.lua`. Enable HTTP requests in Studio. Make requests from a trusted server-side Script only. **Do not put a private key in a LocalScript or any code shipped to players**: client-side secrets can be extracted. For a public game, create a separate backend/proxy that authenticates the Roblox server or user without exposing the master key.

## Security notes / production checklist

- Use HTTPS for hosted deployments.
- Keep `MASTER_API_KEY` in environment variables, never in source control.
- This initial version uses one shared master API key, not per-user keys or a role-based account system. Rotate it from the host environment if exposed.
- Browser dashboard holds the key only in the page's input field (not localStorage); use it on a trusted device and clear it when finished.
- Consider adding rate limiting, request logging, backups, key rotation UI, per-key permissions, and migration tooling before storing sensitive or high-value data.
- CORS is not authentication. API key validation is what protects data endpoints.
- Do not store passwords, payment information, or other highly sensitive data in this starter project.

## Project layout

```text
shadow_api_hub/
├── main.py
├── requirements.txt
├── Procfile
├── render.yaml
├── .env.example
├── .gitignore
├── static/index.html
├── examples/python_client.py
└── examples/luau_client.lua
```
