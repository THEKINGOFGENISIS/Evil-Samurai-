import os, json, hashlib, secrets
from datetime import datetime, timezone
from typing import Optional
from fastapi import FastAPI, Depends, Header, HTTPException, Query
from fastapi.responses import HTMLResponse, Response
from fastapi import UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, String, Text, DateTime, LargeBinary, Integer, select, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, Session, sessionmaker

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./shadow_api.db")
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql://", 1)
connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)

class Base(DeclarativeBase):
    pass

class Item(Base):
    __tablename__ = "items"
    id: Mapped[str] = mapped_column(String(32), primary_key=True)
    name: Mapped[str] = mapped_column(String(120), index=True)
    content: Mapped[str] = mapped_column(Text)
    content_type: Mapped[str] = mapped_column(String(40), default="text")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))


class StoredFile(Base):
    __tablename__ = "stored_files"
    id: Mapped[str] = mapped_column(String(32), primary_key=True)
    filename: Mapped[str] = mapped_column(String(255), index=True)
    content_type: Mapped[str] = mapped_column(String(150), default="application/octet-stream")
    size: Mapped[int] = mapped_column(Integer)
    data: Mapped[bytes] = mapped_column(LargeBinary)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

Base.metadata.create_all(engine)
app = FastAPI(title="Shadow API Hub", version="1.0.0", description="Private key-protected storage API")
app.add_middleware(CORSMiddleware, allow_origins=os.getenv("CORS_ORIGINS", "*").split(","), allow_credentials=False, allow_methods=["GET","POST","PUT","DELETE","OPTIONS"], allow_headers=["X-API-Key","Content-Type"])

MASTER_API_KEY = os.getenv("MASTER_API_KEY", "")
if not MASTER_API_KEY:
    # Safe local development default only; set a strong secret in production.
    MASTER_API_KEY = "dev-only-change-this-key"

class ItemCreate(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    content: str = Field(max_length=1_000_000)
    content_type: str = Field(default="text", max_length=40)

class ItemUpdate(BaseModel):
    name: Optional[str] = Field(default=None, min_length=1, max_length=120)
    content: Optional[str] = Field(default=None, max_length=1_000_000)
    content_type: Optional[str] = Field(default=None, max_length=40)

def verify_key(x_api_key: Optional[str] = Header(default=None, alias="X-API-Key")):
    if not x_api_key or not secrets.compare_digest(x_api_key, MASTER_API_KEY):
        raise HTTPException(status_code=401, detail="Missing or invalid API key")

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def serialize(item: Item):
    return {"id": item.id, "name": item.name, "content": item.content, "content_type": item.content_type,
            "created_at": item.created_at.isoformat() if item.created_at else None,
            "updated_at": item.updated_at.isoformat() if item.updated_at else None}

@app.get("/", response_class=HTMLResponse, include_in_schema=False)
def dashboard():
    path = os.path.join(os.path.dirname(__file__), "static", "index.html")
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


MAX_UPLOAD_BYTES = 10 * 1024 * 1024  # 10 MiB per file

@app.post("/v1/files", status_code=201)
async def upload_file(file: UploadFile = File(...), _: None = Depends(verify_key), db: Session = Depends(get_db)):
    # Read one byte beyond the limit so oversized uploads are rejected.
    data = await file.read(MAX_UPLOAD_BYTES + 1)
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="File exceeds the 10 MiB upload limit")
    filename = (file.filename or "upload.bin").replace("\\\\", "/").split("/")[-1].strip()
    if not filename or filename in {".", ".."}:
        filename = "upload.bin"
    record = StoredFile(
        id=secrets.token_hex(12),
        filename=filename[:255],
        content_type=(file.content_type or "application/octet-stream")[:150],
        size=len(data),
        data=data,
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return {"id": record.id, "filename": record.filename, "content_type": record.content_type,
            "size": record.size, "created_at": record.created_at.isoformat() if record.created_at else None,
            "download_url": f"/v1/files/{record.id}/download"}

@app.get("/v1/files")
def list_files(limit: int = Query(default=50, ge=1, le=100), offset: int = Query(default=0, ge=0),
               _: None = Depends(verify_key), db: Session = Depends(get_db)):
    rows = db.scalars(select(StoredFile).order_by(StoredFile.created_at.desc()).limit(limit).offset(offset)).all()
    total = db.scalar(select(func.count()).select_from(StoredFile))
    return {"files": [{"id": x.id, "filename": x.filename, "content_type": x.content_type,
                       "size": x.size, "created_at": x.created_at.isoformat() if x.created_at else None,
                       "download_url": f"/v1/files/{x.id}/download"} for x in rows],
            "count": len(rows), "total": total}

@app.get("/v1/files/{file_id}/download")
def download_file(file_id: str, _: None = Depends(verify_key), db: Session = Depends(get_db)):
    record = db.get(StoredFile, file_id)
    if not record:
        raise HTTPException(status_code=404, detail="File not found")
    safe_name = record.filename.replace('"', "")
    return Response(content=record.data, media_type=record.content_type,
                    headers={"Content-Disposition": f'attachment; filename="{safe_name}"',
                             "Content-Length": str(record.size), "X-Content-Type-Options": "nosniff"})

@app.delete("/v1/files/{file_id}", status_code=204)
def delete_file(file_id: str, _: None = Depends(verify_key), db: Session = Depends(get_db)):
    record = db.get(StoredFile, file_id)
    if not record:
        raise HTTPException(status_code=404, detail="File not found")
    db.delete(record)
    db.commit()
    return None

@app.get("/health")
def health():
    return {"status": "ok", "service": "Shadow API Hub"}

@app.get("/v1/items")
def list_items(q: Optional[str] = Query(default=None, max_length=120), limit: int = Query(default=50, ge=1, le=100), offset: int = Query(default=0, ge=0), _: None = Depends(verify_key), db: Session = Depends(get_db)):
    stmt = select(Item).order_by(Item.updated_at.desc()).limit(limit).offset(offset)
    if q:
        stmt = select(Item).where(Item.name.ilike(f"%{q}%") if not DATABASE_URL.startswith("sqlite") else Item.name.like(f"%{q}%")).order_by(Item.updated_at.desc()).limit(limit).offset(offset)
    rows = db.scalars(stmt).all()
    total = db.scalar(select(func.count()).select_from(Item))
    return {"items": [serialize(x) for x in rows], "count": len(rows), "total": total, "limit": limit, "offset": offset}

@app.post("/v1/items", status_code=201)
def create_item(payload: ItemCreate, _: None = Depends(verify_key), db: Session = Depends(get_db)):
    if db.scalar(select(Item).where(Item.name == payload.name)):
        raise HTTPException(status_code=409, detail="An item with this name already exists")
    item = Item(id=secrets.token_hex(12), name=payload.name, content=payload.content, content_type=payload.content_type)
    db.add(item); db.commit(); db.refresh(item)
    return serialize(item)

@app.get("/v1/items/{item_id}")
def get_item(item_id: str, _: None = Depends(verify_key), db: Session = Depends(get_db)):
    item = db.get(Item, item_id)
    if not item: raise HTTPException(status_code=404, detail="Item not found")
    return serialize(item)

@app.put("/v1/items/{item_id}")
def update_item(item_id: str, payload: ItemUpdate, _: None = Depends(verify_key), db: Session = Depends(get_db)):
    item = db.get(Item, item_id)
    if not item: raise HTTPException(status_code=404, detail="Item not found")
    changes = payload.model_dump(exclude_unset=True)
    if "name" in changes and changes["name"] != item.name and db.scalar(select(Item).where(Item.name == changes["name"])):
        raise HTTPException(status_code=409, detail="An item with this name already exists")
    for key, value in changes.items(): setattr(item, key, value)
    item.updated_at = datetime.now(timezone.utc)
    db.commit(); db.refresh(item)
    return serialize(item)

@app.delete("/v1/items/{item_id}", status_code=204)
def delete_item(item_id: str, _: None = Depends(verify_key), db: Session = Depends(get_db)):
    item = db.get(Item, item_id)
    if not item: raise HTTPException(status_code=404, detail="Item not found")
    db.delete(item); db.commit()
    return None
