-- Example for a Roblox experience you own, using HttpService.
-- Enable "Allow HTTP Requests" in Roblox Studio security settings.
-- IMPORTANT: Never embed a private API key in a public game/client script.
-- This example is appropriate only for a trusted server-side Script.
local HttpService = game:GetService("HttpService")

local API_URL = "https://YOUR-SERVICE.onrender.com"
local API_KEY = "SET_ON_SERVER_ONLY"

local function request(method, path, body)
    local options = {
        Url = API_URL .. path,
        Method = method,
        Headers = {
            ["X-API-Key"] = API_KEY,
            ["Content-Type"] = "application/json",
        },
    }
    if body then
        options.Body = HttpService:JSONEncode(body)
    end

    local response = HttpService:RequestAsync(options)
    if not response.Success then
        error(("API request failed (%d): %s"):format(response.StatusCode, response.Body))
    end
    if response.Body == "" then return nil end
    return HttpService:JSONDecode(response.Body)
end

-- Create
local saved = request("POST", "/v1/items", {
    name = "roblox-config",
    content_type = "json",
    content = HttpService:JSONEncode({enabled = true, version = 1}),
})
print("Saved record ID:", saved.id)

-- Read
local fetched = request("GET", "/v1/items/" .. saved.id)
print(fetched.name, fetched.content)
