import os
import requests

BASE_URL = os.environ.get("SHADOW_API_URL", "http://127.0.0.1:8000")
API_KEY = os.environ["SHADOW_API_KEY"]
HEADERS = {"X-API-Key": API_KEY}

# Create a record
created = requests.post(
    f"{BASE_URL}/v1/items",
    headers=HEADERS,
    json={"name": "my-config", "content_type": "json", "content": '{"enabled": true, "level": 3}'},
    timeout=20,
)
created.raise_for_status()
item = created.json()
print("Created:", item["id"])

# Read it back
response = requests.get(f"{BASE_URL}/v1/items/" + item["id"], headers=HEADERS, timeout=20)
response.raise_for_status()
print(response.json())

# List records
response = requests.get(f"{BASE_URL}/v1/items", headers=HEADERS, timeout=20)
response.raise_for_status()
print(response.json()["items"])
