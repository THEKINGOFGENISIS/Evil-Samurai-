"""Tạo cấu hình ICE (STUN/TURN) cho WebRTC. Không phụ thuộc aiortc để dễ kiểm thử."""
import base64
import hashlib
import hmac
import time
from typing import Optional

import config


def turn_credentials(tag: str, now: Optional[float] = None) -> Optional[dict]:
    """Thông tin xác thực TURN dạng REST (coturn --use-auth-secret), có thời hạn."""
    if not config.TURN_URLS or not config.TURN_SECRET:
        return None
    expiry = int((now if now is not None else time.time()) + config.TURN_TTL)
    username = f"{expiry}:{tag}"
    digest = hmac.new(config.TURN_SECRET.encode(), username.encode(), hashlib.sha1).digest()
    return {
        "urls": config.TURN_URLS,
        "username": username,
        "credential": base64.b64encode(digest).decode(),
    }


def client_ice(tag: str) -> dict:
    servers = [{"urls": config.STUN_URLS}]
    turn = turn_credentials(tag)
    if turn:
        servers.append(turn)
    return {
        "iceServers": servers,
        "iceTransportPolicy": "relay" if (config.ICE_FORCE_RELAY and turn) else "all",
    }
