"""Kiểm thử phần logic thuần (không cần Docker/Android): chạy `python -m unittest discover -s tests`."""
import os, sys, tempfile, unittest
os.environ["DATA_DIR"] = tempfile.mkdtemp()
os.environ.update(TURN_URLS="turn:example.com:3478", TURN_SECRET="s3cret", JWT_SECRET="x" * 40)
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import inputs, ice, config  # noqa: E402

GETEVENT = '''add device 1: /dev/input/event1
  name:     "redroid-keyboard"
  events:
    KEY (0001): 0001 0002
add device 2: /dev/input/event4
  name:     "redroid-touch0"
  events:
    KEY (0001): 014a
    ABS (0003): 002f  : value 0, min 0, max 9, fuzz 0, flat 0, resolution 0
                0030  : value 0, min 0, max 255, fuzz 0, flat 0, resolution 0
                0035  : value 0, min 0, max 719, fuzz 0, flat 0, resolution 0
                0036  : value 0, min 0, max 1279, fuzz 0, flat 0, resolution 0
                0039  : value 0, min 0, max 65535, fuzz 0, flat 0, resolution 0
  input props:
    INPUT_PROP_DIRECT
'''


class Inputs(unittest.TestCase):
    def setUp(self):
        self.inj = inputs.InputInjector("10.0.0.2", 720, 1280)
        self.inj.profile = inputs.pick_touch_device(inputs.parse_getevent(GETEVENT))

    def test_parse(self):
        p = self.inj.profile
        self.assertEqual((p.path, p.xmax, p.ymax, p.slots), ("/dev/input/event4", 719, 1279, 10))

    def test_touch_sequence(self):
        d = self.inj._r_touch("down", 0, 0.5, 0.5)
        self.assertIn("sendevent /dev/input/event4 3 53 359", d)
        self.assertIn("sendevent /dev/input/event4 1 330 1", d)
        d2 = self.inj._r_touch("down", 1, 0.1, 0.1)        # ngón thứ hai: không BTN_TOUCH
        self.assertNotIn("1 330", d2)
        self.assertEqual(self.inj._r_touch("move", 7, 0, 0), "")  # chưa down
        u1 = self.inj._r_touch("up", 0, 0, 0)
        self.assertNotIn("1 330 0", u1)
        u2 = self.inj._r_touch("up", 1, 0, 0)
        self.assertIn("1 330 0", u2)
        self.assertIn("3 57 -1", u2)

    def test_coalesce(self):
        b = [("touch", "down", 0, 0, 0), ("touch", "move", 0, .1, .1), ("touch", "move", 0, .2, .2), ("touch", "up", 0, 0, 0)]
        self.assertEqual(len(inputs.InputInjector._coalesce(b)), 2)

    def test_fallback(self):
        self.inj.profile = None
        self.inj._r_touch_fb("down", 0, 0.5, 0.5)
        self.assertTrue(self.inj._r_touch_fb("up", 0, 0.5, 0.5).startswith("input tap"))
        self.inj._r_touch_fb("down", 0, 0.1, 0.1); self.inj._r_touch_fb("move", 0, 0.9, 0.9)
        self.assertTrue(self.inj._r_touch_fb("up", 0, 0.9, 0.9).startswith("input swipe"))

    def test_text_and_keys(self):
        self.assertEqual(inputs.render_text("a b", False), "input text a%sb")
        self.assertIn("'%'", inputs.render_text("50%", False))
        self.assertIsNone(inputs.render_text("xin chào", False))
        self.assertIn("ADB_INPUT_B64", inputs.render_text("xin chào", True))
        self.assertEqual(inputs.render_text("a;rm -rf /", False), "input text 'a;rm%s-rf%s/'")
        self.assertEqual(inputs.resolve_key("home"), 3)
        self.assertIsNone(inputs.resolve_key("nope"))
        self.assertIsNone(inputs.resolve_key(99999))


class Ice(unittest.TestCase):
    def test_turn(self):
        c = ice.turn_credentials("bob", now=1000)
        self.assertEqual(c["username"], f"{1000 + config.TURN_TTL}:bob")
        self.assertTrue(c["credential"])
        self.assertEqual(ice.client_ice("bob")["iceTransportPolicy"], "all")


class Auth(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            import fastapi  # noqa: F401
        except ImportError:  # môi trường kiểm thử không có fastapi: dùng bản giả tối thiểu
            import types
            fa = types.ModuleType("fastapi")
            class HTTPException(Exception):
                def __init__(self, status_code, detail=None, headers=None):
                    super().__init__(detail); self.status_code = status_code
            fa.HTTPException, fa.Request = HTTPException, object
            sys.modules["fastapi"] = fa
        import auth
        cls.auth = auth

    def test_all(self):
        if not self.auth:
            self.skipTest("fastapi chưa cài")
        a = self.auth
        a.init()
        h = a.hash_password("correct horse battery")
        self.assertTrue(a.verify_password("correct horse battery", h))
        self.assertFalse(a.verify_password("wrong", h))
        uid = a.create_user("bob", "correct horse battery")
        self.assertIsNotNone(a.authenticate("bob", "correct horse battery"))
        self.assertIsNone(a.authenticate("bob", "nope"))
        user = a.get_user(uid)
        access, refresh = a.issue(user)
        self.assertEqual(a.decode(access, "access")["sub"], str(uid))
        u, acc2, ref2 = a.rotate(refresh)
        with self.assertRaises(Exception):
            a.rotate(refresh)           # dùng lại token cũ bị từ chối
        with self.assertRaises(Exception):
            a.rotate(ref2)              # và toàn bộ phiên bị thu hồi
        lim = a.LoginLimiter(max_fail=3, lock_s=60)
        for _ in range(3):
            lim.fail("1.1.1.1", "bob")
        self.assertGreater(lim.retry_after("1.1.1.1", "bob"), 0)


class AdbDiagnose(unittest.TestCase):
    """Chẩn đoán dùng adb giả (tests/fake_adb.py) để kiểm tra logic báo lỗi chính xác, không cần Android thật."""
    FAKE = os.path.join(os.path.dirname(__file__), "fake_adb.py")

    def run_mode(self, mode, adb_bin=None):
        import importlib
        os.environ["FAKE_MODE"] = mode
        os.environ["ADB_BIN"] = adb_bin or self.FAKE
        import adb
        importlib.reload(adb)
        return adb, {s["id"]: s for s in adb.diagnose("10.0.0.2")}

    def test_all_ok(self):
        _, st = self.run_mode("ok")
        self.assertTrue(all(s["ok"] for s in st.values()), st)
        self.assertIn("720x1280", st["screencap"]["detail"])

    def test_connect_failure_is_reported_exactly(self):
        _, st = self.run_mode("noconn")
        self.assertFalse(st["connect"]["ok"])
        self.assertIn("failed to connect", st["connect"]["detail"])
        self.assertIsNone(st["screencap"]["ok"])           # bước sau bị bỏ qua, không báo thành công giả

    def test_booting(self):
        _, st = self.run_mode("booting")
        self.assertFalse(st["boot"]["ok"])

    def test_screencap_failure(self):
        _, st = self.run_mode("nocap")
        self.assertFalse(st["screencap"]["ok"])
        self.assertIn("Display not found", st["screencap"]["detail"])

    def test_screenrecord_failure(self):
        _, st = self.run_mode("norec")
        self.assertFalse(st["screenrecord"]["ok"])
        self.assertIn("unable to configure codec", st["screenrecord"]["detail"])

    def test_missing_adb_binary(self):
        _, st = self.run_mode("ok", "/nonexistent/adb")
        self.assertFalse(st["adb"]["ok"])
        self.assertIn("Không tìm thấy", st["adb"]["detail"])

    def test_png_size(self):
        adb, _ = self.run_mode("ok")
        png, err = adb.screencap_png_ex("10.0.0.2")
        self.assertIsNone(err)
        self.assertEqual(adb.png_size(png), (720, 1280))
        self.assertIsNone(adb.png_size(b"not a png"))


if __name__ == "__main__":
    unittest.main()
