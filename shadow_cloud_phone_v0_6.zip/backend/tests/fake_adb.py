#!/usr/bin/env python3
import os, sys, struct, zlib
mode = os.environ.get("FAKE_MODE", "ok")
a = sys.argv[1:]
if a and a[0] == "-s": a = a[2:]
def png(w=720, h=1280):
    def ch(t, d): return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    raw = b"".join(b"\x00" + b"\x00\x00\x00" * w for _ in range(2))
    return b"\x89PNG\r\n\x1a\n" + ch(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)) + ch(b"IDAT", zlib.compress(raw)) + ch(b"IEND", b"")
if a[:1] == ["version"]: print("Android Debug Bridge version 1.0.41"); sys.exit(0)
if a[:1] == ["connect"]:
    if mode == "noconn": print("failed to connect to 10.0.0.2:5555"); sys.exit(0)
    print("connected to 10.0.0.2:5555"); sys.exit(0)
if a[:1] == ["get-state"]:
    if mode == "noconn": sys.stderr.write("error: device '10.0.0.2:5555' not found\n"); sys.exit(1)
    print("device"); sys.exit(0)
if a[:1] == ["exec-out"]:
    if a[1] == "screencap":
        if mode == "nocap": sys.stderr.write("screencap: Display not found\n"); sys.exit(1)
        sys.stdout.buffer.write(png()); sys.exit(0)
    if a[1] == "screenrecord":
        if mode == "norec": sys.stderr.write("ERROR: unable to configure codec\n"); sys.exit(1)
        sys.stdout.buffer.write(b"\x00\x00\x00\x01\x67" + b"\x42" * 3000); sys.exit(0)
if a[:1] == ["shell"]:
    cmd = a[1]
    if "sys.boot_completed" in cmd and "release" in cmd: print("0" if mode == "booting" else "1"); print("13"); print("redroid13_x86_64"); sys.exit(0)
    if cmd.startswith("getprop sys.boot"): print("0" if mode == "booting" else "1"); sys.exit(0)
    if cmd == "wm size": print("Physical size: 720x1280"); sys.exit(0)
    if cmd == "getevent -p":
        print('add device 1: /dev/input/event4\n  name:     "redroid-touch0"\n  events:\n    ABS (0003): 002f  : value 0, min 0, max 9, fuzz 0, flat 0, resolution 0\n                0035  : value 0, min 0, max 719, fuzz 0, flat 0, resolution 0\n                0036  : value 0, min 0, max 1279, fuzz 0, flat 0, resolution 0'); sys.exit(0)
    if cmd.startswith("pm list"): sys.exit(0)
sys.exit(0)
