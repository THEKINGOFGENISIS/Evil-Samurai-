"""Giao tiếp ADB với container redroid qua mạng nội bộ Docker (cổng 5555 không publish ra ngoài)."""
import logging
import os
import re
import subprocess
from typing import List, Optional, Tuple

import config

log = logging.getLogger("shadow.adb")

ADB = os.getenv("ADB_BIN", "adb")
PORT = 5555
# Dùng ADB server riêng (5038) để không đụng ADB server của máy chủ (5037).
ENV = {
    **os.environ,
    "ANDROID_ADB_SERVER_PORT": os.getenv("ADB_SERVER_PORT", "5038"),
    "HOME": str(config.DATA_DIR / "home"),
}


LAST_ERR: dict = {}        # ip -> lỗi ADB gần nhất (None khi bình thường), để giao diện hiển thị đúng nguyên nhân


def serial(ip: str) -> str:
    return f"{ip}:{PORT}"


def _clean(text: str, limit: int = 240) -> str:
    return " ".join((text or "").split())[:limit]


def run(args: List[str], timeout: float = 8) -> Tuple[int, str]:
    try:
        p = subprocess.run([ADB, *args], capture_output=True, text=True, timeout=timeout, env=ENV)
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as exc:
        return 255, str(exc)
    return p.returncode, (p.stdout or "") + (p.stderr or "")


def ensure_connected(ip: str) -> bool:
    s = serial(ip)
    rc, out = run(["-s", s, "get-state"], timeout=4)
    if rc == 0 and "device" in out:
        LAST_ERR[ip] = None
        return True
    rc, out = run(["connect", s], timeout=6)
    low = out.lower()
    if "connected" in low and "cannot" not in low and "failed" not in low:
        rc, out2 = run(["-s", s, "get-state"], timeout=4)
        if rc == 0 and "device" in out2:
            LAST_ERR[ip] = None
            return True
        out = out2
    if rc == 255 and ("No such file" in out or "not found" in out.lower()):
        LAST_ERR[ip] = f"Không tìm thấy chương trình adb ({ADB}). Hãy cài android-tools-adb hoặc đặt ADB_BIN."
    else:
        LAST_ERR[ip] = "ADB không kết nối được tới " + s + ": " + (_clean(out) or "không có phản hồi")
    return False


def shell(ip: str, cmd: str, timeout: float = 8) -> Tuple[int, str]:
    return run(["-s", serial(ip), "shell", cmd], timeout=timeout)


def boot_completed(ip: str) -> bool:
    if not ensure_connected(ip):
        return False
    rc, out = shell(ip, "getprop sys.boot_completed", timeout=4)
    ok = rc == 0 and out.strip() == "1"
    LAST_ERR[ip] = None if ok else "Android đang khởi động (sys.boot_completed chưa bằng 1)."
    return ok


_SIZE = re.compile(r"(\d+)x(\d+)")


def screen_size(ip: str) -> Tuple[int, int]:
    """Kích thước màn hình thực (px). Ưu tiên 'Override size' nếu có."""
    rc, out = shell(ip, "wm size", timeout=5)
    size = None
    for line in out.splitlines():
        m = _SIZE.search(line)
        if m:
            size = (int(m.group(1)), int(m.group(2)))
            if line.lower().startswith("override"):
                break
    return size or (config.ANDROID_WIDTH, config.ANDROID_HEIGHT)


def png_size(data: bytes) -> Optional[Tuple[int, int]]:
    """Đọc kích thước từ header PNG (IHDR). None nếu không phải PNG hợp lệ."""
    if len(data) < 24 or not data.startswith(b"\x89PNG\r\n\x1a\n") or data[12:16] != b"IHDR":
        return None
    return int.from_bytes(data[16:20], "big"), int.from_bytes(data[20:24], "big")


def screencap_png_ex(ip: str) -> Tuple[Optional[bytes], Optional[str]]:
    """Chụp màn hình thật bằng `adb exec-out screencap -p`. Trả về (png, None) hoặc (None, lỗi chính xác)."""
    try:
        p = subprocess.run([ADB, "-s", serial(ip), "exec-out", "screencap", "-p"],
                           capture_output=True, timeout=15, env=ENV)
    except subprocess.TimeoutExpired:
        return None, "screencap quá thời gian chờ (15 giây)."
    except FileNotFoundError:
        return None, f"Không tìm thấy chương trình adb ({ADB})."
    except OSError as exc:
        return None, f"Không chạy được adb: {exc}"
    if p.returncode != 0:
        return None, "screencap lỗi: " + (_clean(p.stderr.decode("utf-8", "replace")) or f"mã thoát {p.returncode}")
    size = png_size(p.stdout)
    if not size:
        return None, "screencap không trả về ảnh PNG hợp lệ: " + (_clean(p.stdout[:200].decode("utf-8", "replace")) or "dữ liệu rỗng")
    if size[0] < 2 or size[1] < 2:
        return None, f"Ảnh chụp có kích thước không hợp lệ ({size[0]}x{size[1]})."
    return p.stdout, None


def screencap_png(ip: str) -> Optional[bytes]:
    return screencap_png_ex(ip)[0]


def prepare_screen(ip: str) -> None:
    """Đánh thức màn hình và không cho tắt: cần để screenrecord luôn có hình."""
    shell(ip, "input keyevent 224; svc power stayon true; "
              "settings put system screen_off_timeout 2147483647", timeout=8)


def provision(ip: str) -> None:
    """Cài các APK trong thư mục ./apks một lần cho mỗi thiết bị (nếu có)."""
    marker = "/data/local/tmp/.shadow_provisioned"
    rc, out = shell(ip, f"test -f {marker} && echo yes", timeout=4)
    if "yes" in out:
        return
    apks = sorted(config.APK_DIR.glob("*.apk")) if config.APK_DIR.is_dir() else []
    for apk in apks:
        rc, out = run(["-s", serial(ip), "install", "-r", str(apk)], timeout=180)
        log.info("install %s -> %s", apk.name, out.strip()[-120:])
    # Bàn phím ADBKeyboard (nếu người dùng đặt ADBKeyboard.apk vào ./apks) để gõ Unicode/tiếng Việt.
    rc, out = shell(ip, "pm list packages com.android.adbkeyboard", timeout=6)
    if "com.android.adbkeyboard" in out:
        shell(ip, "ime enable com.android.adbkeyboard/.AdbIME; ime set com.android.adbkeyboard/.AdbIME", timeout=8)
    shell(ip, f"touch {marker}", timeout=4)


def has_adb_keyboard(ip: str) -> bool:
    rc, out = shell(ip, "pm list packages com.android.adbkeyboard", timeout=6)
    return "com.android.adbkeyboard" in out


# ---------------------------------------------------------------- chẩn đoán thật
def version() -> Tuple[bool, str]:
    """Kiểm tra chương trình adb có chạy được không (không cần thiết bị)."""
    rc, out = run(["version"], timeout=5)
    if rc == 0:
        first = _clean(out.splitlines()[0] if out.splitlines() else out, 120)
        return True, first
    if rc == 255 and ("No such file" in out or "not found" in out.lower()):
        return False, f"Không tìm thấy chương trình adb ({ADB})."
    return False, _clean(out) or f"adb thoát với mã {rc}"


def probe_screenrecord(ip: str, width: int, height: int, seconds: int = 2) -> Tuple[bool, str]:
    """Chạy screenrecord H.264 thật trong vài giây và kiểm tra có dữ liệu video hay không."""
    cmd = [ADB, "-s", serial(ip), "exec-out", "screenrecord", "--output-format=h264",
           "--size", f"{width}x{height}", "--bit-rate", "1000000", "--time-limit", str(seconds), "-"]
    try:
        p = subprocess.run(cmd, capture_output=True, timeout=seconds + 8, env=ENV)
    except subprocess.TimeoutExpired:
        return False, "screenrecord không kết thúc đúng hạn (treo)."
    except OSError as exc:
        return False, f"Không chạy được adb: {exc}"
    err = _clean(p.stderr.decode("utf-8", "replace"))
    data = p.stdout
    if not data:
        return False, "screenrecord không xuất dữ liệu" + (f": {err}" if err else f" (mã thoát {p.returncode}).")
    if b"\x00\x00\x00\x01" not in data[:4096] and b"\x00\x00\x01" not in data[:4096]:
        return False, f"Dữ liệu không phải luồng H.264 ({len(data)} byte). " + (err or _clean(data[:120].decode('utf-8', 'replace')))
    return True, f"{len(data) // 1024} KB H.264 trong {seconds} giây"


def diagnose(ip: str) -> List[dict]:
    """Kiểm tra từng tầng với Android thật. Mỗi bước: {id, label, ok(True/False/None), detail, ms}.
    ok=None nghĩa là bị bỏ qua vì bước trước đó đã lỗi."""
    import time
    steps: List[dict] = []
    broken = [False]

    def step(sid: str, label: str, fn, critical: bool = True):
        if broken[0]:
            steps.append({"id": sid, "label": label, "ok": None, "detail": "Bỏ qua vì bước trước bị lỗi.", "ms": 0})
            return None
        t0 = time.monotonic()
        try:
            ok, detail, value = fn()
        except Exception as exc:  # noqa: BLE001
            ok, detail, value = False, f"Lỗi không mong đợi: {exc}", None
        steps.append({"id": sid, "label": label, "ok": ok, "detail": detail, "ms": int((time.monotonic() - t0) * 1000)})
        if not ok and critical:
            broken[0] = True
        return value

    def s_adb():
        ok, d = version()
        return ok, d, None

    def s_conn():
        ok = ensure_connected(ip)
        return ok, ("Đã kết nối " + serial(ip)) if ok else (LAST_ERR.get(ip) or "Không kết nối được."), None

    def s_boot():
        rc, out = shell(ip, "getprop sys.boot_completed; getprop ro.build.version.release; getprop ro.product.model", timeout=6)
        lines = [l.strip() for l in out.splitlines() if l.strip()]
        if rc != 0 or not lines:
            return False, "Không đọc được thuộc tính Android: " + (_clean(out) or f"mã thoát {rc}"), None
        if lines[0] != "1":
            return False, "Android chưa boot xong (sys.boot_completed=" + lines[0] + ").", None
        ver = lines[1] if len(lines) > 1 else "?"
        return True, f"Android {ver}" + (f" · {lines[2]}" if len(lines) > 2 else ""), None

    def s_size():
        rc, out = shell(ip, "wm size", timeout=5)
        m = _SIZE.search(out or "")
        if rc != 0 or not m:
            return False, "Không đọc được kích thước màn hình: " + (_clean(out) or f"mã thoát {rc}"), None
        w, h = screen_size(ip)
        return True, f"{w}x{h}", (w, h)

    def s_cap():
        png, err = screencap_png_ex(ip)
        if not png:
            return False, err or "Không chụp được màn hình.", None
        wh = png_size(png)
        return True, f"Ảnh PNG thật {wh[0]}x{wh[1]} ({len(png) // 1024} KB)", None

    def s_rec(size):
        w, h = size or (config.ANDROID_WIDTH, config.ANDROID_HEIGHT)
        tw = min(360, w)
        th = round(h * tw / w)
        ok, d = probe_screenrecord(ip, tw - tw % 2, th - th % 2)
        return ok, d, None

    def s_input():
        import inputs  # nhập muộn để tránh vòng phụ thuộc
        rc, out = shell(ip, "getevent -p", timeout=8)
        if rc != 0:
            return False, "getevent lỗi: " + (_clean(out) or f"mã thoát {rc}"), None
        prof = inputs.pick_touch_device(inputs.parse_getevent(out))
        if prof:
            return True, f"Cảm ứng đa điểm qua sendevent: {prof.name or prof.path} ({prof.slots} ngón)", None
        return True, "Không dò được thiết bị cảm ứng; dùng chế độ dự phòng `input tap/swipe` (vuốt thực hiện khi nhả tay).", None

    def s_kb():
        ok = has_adb_keyboard(ip)
        return True, "ADBKeyboard đã cài: gõ được Unicode/tiếng Việt." if ok else \
            "Chưa cài ADBKeyboard: chỉ gõ được ký tự ASCII (đặt ADBKeyboard.apk vào thư mục apks/).", None

    step("adb", "Chương trình ADB", s_adb)
    step("connect", "Kết nối ADB tới Android", s_conn)
    step("boot", "Android đã boot", s_boot)
    size = step("size", "Kích thước màn hình", s_size)
    step("screencap", "Chụp ảnh màn hình thật (screencap)", s_cap, critical=False)
    # screenrecord/input chỉ cần ADB + boot; vẫn chạy dù screencap lỗi để biết chính xác tầng nào hỏng.
    step("screenrecord", "Luồng video H.264 (screenrecord)", lambda: s_rec(size), critical=False)
    step("input", "Điều khiển cảm ứng/phím", s_input, critical=False)
    step("keyboard", "Bàn phím Unicode", s_kb, critical=False)
    return steps
