"""Xác thực & phân quyền: người dùng (SQLite), mật khẩu scrypt, JWT truy cập + refresh xoay vòng."""
import base64
import hashlib
import hmac
import logging
import secrets
import sqlite3
import threading
import time
import uuid
from typing import Optional

import jwt
from fastapi import HTTPException, Request

import config

log = logging.getLogger("shadow.auth")
COOKIE = "shadow_rt"
_lock = threading.RLock()
_conn: Optional[sqlite3.Connection] = None


def db() -> sqlite3.Connection:
    global _conn
    if _conn is None:
        _conn = sqlite3.connect(str(config.DATA_DIR / "shadow.db"), check_same_thread=False, isolation_level=None)
        _conn.row_factory = sqlite3.Row
        _conn.execute("PRAGMA journal_mode=WAL")
    return _conn


def q(sql: str, args=()):
    with _lock:
        return db().execute(sql, args).fetchall()


def x(sql: str, args=()):
    with _lock:
        return db().execute(sql, args)


def init() -> None:
    x("""CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL COLLATE NOCASE,
        pw_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user', disabled INTEGER NOT NULL DEFAULT 0,
        created_at INTEGER NOT NULL)""")
    x("""CREATE TABLE IF NOT EXISTS refresh(
        jti TEXT PRIMARY KEY, user_id INTEGER NOT NULL, exp INTEGER NOT NULL, revoked INTEGER NOT NULL DEFAULT 0)""")
    x("""CREATE TABLE IF NOT EXISTS audit(
        id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, user TEXT, action TEXT NOT NULL,
        target TEXT, ip TEXT, detail TEXT)""")
    if not q("SELECT 1 FROM users LIMIT 1"):
        pw = config.ADMIN_PASSWORD
        generated = False
        if len(pw) < 10:
            pw, generated = secrets.token_urlsafe(14), True
        create_user(config.ADMIN_USERNAME, pw, "admin")
        if generated:
            log.warning("=" * 60)
            log.warning("Tài khoản quản trị đầu tiên: %s / %s", config.ADMIN_USERNAME, pw)
            log.warning("Mật khẩu này chỉ hiển thị MỘT lần. Hãy đổi ngay sau khi đăng nhập.")
            log.warning("=" * 60)


# ---- mật khẩu ----
def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    h = hashlib.scrypt(password.encode(), salt=salt, n=2 ** 14, r=8, p=1, dklen=32)
    return "scrypt$14$8$1$%s$%s" % (base64.b64encode(salt).decode(), base64.b64encode(h).decode())


def verify_password(password: str, stored: str) -> bool:
    try:
        _, n, r, p, salt, h = stored.split("$")
        calc = hashlib.scrypt(password.encode(), salt=base64.b64decode(salt), n=2 ** int(n), r=int(r),
                              p=int(p), dklen=32)
        return hmac.compare_digest(calc, base64.b64decode(h))
    except (ValueError, TypeError):
        return False


_DUMMY = None


def authenticate(username: str, password: str):
    global _DUMMY
    if _DUMMY is None:
        _DUMMY = hash_password("dummy-password")
    rows = q("SELECT * FROM users WHERE username=?", (username,))
    user = rows[0] if rows else None
    ok = verify_password(password, user["pw_hash"] if user else _DUMMY)  # thời gian xử lý đều nhau
    return user if (user and ok and not user["disabled"]) else None


# ---- người dùng ----
def create_user(username: str, password: str, role: str = "user") -> int:
    cur = x("INSERT INTO users(username,pw_hash,role,created_at) VALUES(?,?,?,?)",
            (username, hash_password(password), role, int(time.time())))
    return cur.lastrowid


def get_user(uid: int):
    rows = q("SELECT * FROM users WHERE id=?", (uid,))
    return rows[0] if rows else None


def list_users():
    return [public(u) for u in q("SELECT * FROM users ORDER BY id")]


def public(u) -> dict:
    return {"id": u["id"], "username": u["username"], "role": u["role"], "disabled": bool(u["disabled"]),
            "created_at": u["created_at"]}


def set_password(uid: int, password: str) -> None:
    x("UPDATE users SET pw_hash=? WHERE id=?", (hash_password(password), uid))
    x("UPDATE refresh SET revoked=1 WHERE user_id=?", (uid,))


def delete_user(uid: int) -> None:
    x("DELETE FROM users WHERE id=?", (uid,))
    x("DELETE FROM refresh WHERE user_id=?", (uid,))


def count_admins() -> int:
    return q("SELECT COUNT(*) c FROM users WHERE role='admin' AND disabled=0")[0]["c"]


# ---- token ----
def _encode(user, typ: str, ttl: int):
    now, jti = int(time.time()), uuid.uuid4().hex
    token = jwt.encode({"sub": str(user["id"]), "role": user["role"], "typ": typ, "jti": jti, "iat": now,
                        "exp": now + ttl, "iss": "shadow-cloud"}, config.JWT_SECRET, algorithm="HS256")
    return token, jti, now + ttl


def decode(token: str, typ: str) -> dict:
    try:
        p = jwt.decode(token, config.JWT_SECRET, algorithms=["HS256"], issuer="shadow-cloud",
                       options={"require": ["exp", "sub", "typ", "jti"]})
    except jwt.PyJWTError:
        raise HTTPException(401, "Phiên đăng nhập không hợp lệ hoặc đã hết hạn.")
    if p.get("typ") != typ:
        raise HTTPException(401, "Loại token không hợp lệ.")
    return p


def issue(user):
    access, _, _ = _encode(user, "access", config.ACCESS_TTL)
    refresh, jti, exp = _encode(user, "refresh", config.REFRESH_TTL)
    x("INSERT INTO refresh(jti,user_id,exp) VALUES(?,?,?)", (jti, user["id"], exp))
    x("DELETE FROM refresh WHERE exp < ?", (int(time.time()),))
    return access, refresh


def rotate(refresh_token: str):
    p = decode(refresh_token, "refresh")
    rows = q("SELECT * FROM refresh WHERE jti=?", (p["jti"],))
    user = get_user(int(p["sub"]))
    if not rows or not user or user["disabled"]:
        raise HTTPException(401, "Phiên đăng nhập không hợp lệ.")
    if rows[0]["revoked"]:  # token cũ bị dùng lại => nghi bị đánh cắp, thu hồi toàn bộ
        x("UPDATE refresh SET revoked=1 WHERE user_id=?", (user["id"],))
        raise HTTPException(401, "Phiên đăng nhập không hợp lệ.")
    x("UPDATE refresh SET revoked=1 WHERE jti=?", (p["jti"],))
    return user, *issue(user)


def revoke(refresh_token: Optional[str]) -> None:
    if not refresh_token:
        return
    try:
        p = decode(refresh_token, "refresh")
        x("UPDATE refresh SET revoked=1 WHERE jti=?", (p["jti"],))
    except HTTPException:
        pass


def current_user(request: Request):
    h = request.headers.get("authorization", "")
    if not h.lower().startswith("bearer "):
        raise HTTPException(401, "Cần đăng nhập.")
    p = decode(h[7:].strip(), "access")
    user = get_user(int(p["sub"]))
    if not user or user["disabled"]:
        raise HTTPException(401, "Tài khoản không khả dụng.")
    return user


def require_admin(request: Request):
    user = current_user(request)
    if user["role"] != "admin":
        raise HTTPException(403, "Chỉ quản trị viên mới được phép.")
    return user


# ---- chống dò mật khẩu ----
class LoginLimiter:
    def __init__(self, max_fail: int = 5, lock_s: int = 300):
        self.max_fail, self.lock_s = max_fail, lock_s
        self.fails: dict = {}
        self.lock = threading.Lock()

    def retry_after(self, ip: str, username: str) -> int:
        now = time.time()
        with self.lock:
            for key in (f"u:{ip}|{username.lower()}", f"ip:{ip}"):
                n, until = self.fails.get(key, (0, 0))
                if until > now:
                    return int(until - now) + 1
        return 0

    def fail(self, ip: str, username: str) -> None:
        now = time.time()
        with self.lock:
            for key, limit in ((f"u:{ip}|{username.lower()}", self.max_fail), (f"ip:{ip}", self.max_fail * 4)):
                n, until = self.fails.get(key, (0, 0))
                n += 1
                self.fails[key] = (0, now + self.lock_s) if n >= limit else (n, until)

    def success(self, ip: str, username: str) -> None:
        with self.lock:
            self.fails.pop(f"u:{ip}|{username.lower()}", None)


login_limiter = LoginLimiter()


class RateLimiter:
    def __init__(self, per_min: int):
        self.per_min, self.hits, self.lock = per_min, {}, threading.Lock()

    def allow(self, ip: str) -> bool:
        now = time.time()
        with self.lock:
            start, n = self.hits.get(ip, (now, 0))
            if now - start > 60:
                start, n = now, 0
            self.hits[ip] = (start, n + 1)
            if len(self.hits) > 10000:
                self.hits = {k: v for k, v in self.hits.items() if now - v[0] < 60}
            return n + 1 <= self.per_min


def client_ip(request: Request) -> str:
    peer = request.client.host if request.client else "unknown"
    if peer in config.TRUSTED_PROXIES:
        xff = request.headers.get("x-forwarded-for", "")
        if xff:
            return xff.split(",")[-1].strip() or peer
    return peer


# ---- nhật ký ----
def audit(user: Optional[str], action: str, target: str = "", ip: str = "", detail: str = "") -> None:
    x("INSERT INTO audit(ts,user,action,target,ip,detail) VALUES(?,?,?,?,?,?)",
      (int(time.time()), user, action, target, ip, detail[:300]))
    x("DELETE FROM audit WHERE id <= (SELECT MAX(id) FROM audit) - 5000")


def audit_list(user, limit: int = 100):
    limit = max(1, min(limit, 200))
    if user["role"] == "admin":
        rows = q("SELECT * FROM audit ORDER BY id DESC LIMIT ?", (limit,))
    else:
        rows = q("SELECT * FROM audit WHERE user=? ORDER BY id DESC LIMIT ?", (user["username"], limit))
    return [dict(r) for r in rows]
