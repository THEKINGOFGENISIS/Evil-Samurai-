"""Điều khiển Android thật: cảm ứng đa điểm, vuốt, phím, văn bản.

Đường nhanh: ghi sự kiện cảm ứng trực tiếp vào thiết bị input của Android bằng `sendevent`
qua MỘT phiên `adb shell` giữ sẵn (không spawn tiến trình adb cho mỗi cú chạm).
Đường dự phòng: nếu không dò được thiết bị cảm ứng, dùng `input tap/swipe`.
"""
import asyncio
import base64
import logging
import re
import shlex
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import adb as adbmod

log = logging.getLogger("shadow.input")

KEYMAP = {
    "HOME": 3, "BACK": 4, "UP": 19, "DOWN": 20, "LEFT": 21, "RIGHT": 22, "CENTER": 23,
    "VOLUME_UP": 24, "VOLUME_DOWN": 25, "POWER": 26, "TAB": 61, "SPACE": 62, "ENTER": 66,
    "BACKSPACE": 67, "MENU": 82, "SEARCH": 84, "PAGE_UP": 92, "PAGE_DOWN": 93,
    "ESCAPE": 111, "DELETE": 112, "MOVE_HOME": 122, "MOVE_END": 123, "MUTE": 164,
    "APP_SWITCH": 187, "SLEEP": 223, "WAKEUP": 224,
}

EV_SYN, EV_KEY, EV_ABS = 0, 1, 3
BTN_TOUCH = 330
ABS_MT_SLOT, ABS_MT_TOUCH_MAJOR, ABS_MT_POSITION_X, ABS_MT_POSITION_Y = 0x2F, 0x30, 0x35, 0x36
ABS_MT_TRACKING_ID, ABS_MT_PRESSURE = 0x39, 0x3A
MAX_FINGERS = 5

_DEV = re.compile(r"^add device \d+:\s+(\S+)")
_NAME = re.compile(r'^\s+name:\s+"(.*)"')
_ABS = re.compile(r"^\s+(?:ABS\s+\(0003\):\s+)?([0-9a-fA-F]{4})\s+:\s+value\s+-?\d+,\s+min\s+(-?\d+),\s+max\s+(-?\d+)")


@dataclass
class TouchProfile:
    path: str
    name: str
    xmax: int
    ymax: int
    slots: int
    abs: Dict[int, Tuple[int, int]] = field(default_factory=dict)


def parse_getevent(text: str) -> List[dict]:
    """Phân tích đầu ra `getevent -p` thành danh sách thiết bị và dải giá trị ABS."""
    devices: List[dict] = []
    cur: Optional[dict] = None
    for line in text.splitlines():
        m = _DEV.match(line)
        if m:
            cur = {"path": m.group(1), "name": "", "abs": {}}
            devices.append(cur)
            continue
        if cur is None:
            continue
        m = _NAME.match(line)
        if m:
            cur["name"] = m.group(1)
            continue
        m = _ABS.match(line)
        if m:
            cur["abs"][int(m.group(1), 16)] = (int(m.group(2)), int(m.group(3)))
    return devices


def pick_touch_device(devices: List[dict]) -> Optional[TouchProfile]:
    cands = [d for d in devices
             if ABS_MT_POSITION_X in d["abs"] and ABS_MT_POSITION_Y in d["abs"] and ABS_MT_SLOT in d["abs"]]
    if not cands:
        return None
    cands.sort(key=lambda d: 0 if "touch" in d["name"].lower() else 1)
    d = cands[0]
    return TouchProfile(
        path=d["path"], name=d["name"],
        xmax=d["abs"][ABS_MT_POSITION_X][1], ymax=d["abs"][ABS_MT_POSITION_Y][1],
        slots=d["abs"][ABS_MT_SLOT][1] + 1, abs=d["abs"],
    )


def resolve_key(k) -> Optional[int]:
    if isinstance(k, bool):
        return None
    if isinstance(k, int):
        return k if 0 < k < 400 else None
    if isinstance(k, str):
        name = k.upper().replace("KEYCODE_", "")
        return KEYMAP.get(name)
    return None


def render_text(s: str, unicode_ok: bool) -> Optional[str]:
    """Lệnh shell để gõ văn bản. None nếu không hỗ trợ ký tự (cần ADBKeyboard)."""
    s = s[:200]
    if not s:
        return ""
    if all(32 <= ord(c) < 127 for c in s):
        cmds = []
        for i, part in enumerate(s.split("%")):
            if i > 0:
                cmds.append("input text '%'")
            if part:
                cmds.append("input text " + shlex.quote(part.replace(" ", "%s")))
        return "; ".join(cmds)
    if unicode_ok:
        b64 = base64.b64encode(s.encode("utf-8")).decode()
        return f"am broadcast -a ADB_INPUT_B64 --es msg {b64}"
    return None


class InputInjector:
    def __init__(self, ip: str, width: int, height: int):
        self.ip = ip
        self.w, self.h = width, height
        self.profile: Optional[TouchProfile] = None
        self.unicode_ok = False
        self.q: asyncio.Queue = asyncio.Queue(maxsize=1024)
        self.proc: Optional[asyncio.subprocess.Process] = None
        self.task: Optional[asyncio.Task] = None
        self.active: Dict[int, int] = {}          # pid -> tracking id
        self.fb: Dict[int, list] = {}             # chế độ dự phòng: pid -> [x0,y0,t0,x1,y1]
        self._tid = 0
        self._last_scroll = 0.0
        self.last_error: Optional[str] = None     # lỗi thật khi ghi lệnh vào Android (None = ổn)

    @property
    def mode(self) -> str:
        return "sendevent" if self.profile else "input"

    # ---- vòng đời ----
    async def start(self) -> None:
        await asyncio.to_thread(self._probe)
        await self._spawn()
        self.task = asyncio.create_task(self._worker())
        log.info("input mode=%s device=%s", self.mode, self.profile.path if self.profile else "-")

    def _probe(self) -> None:
        rc, out = adbmod.shell(self.ip, "getevent -p", timeout=8)
        self.profile = pick_touch_device(parse_getevent(out)) if rc == 0 else None
        self.unicode_ok = adbmod.has_adb_keyboard(self.ip)

    async def _spawn(self) -> None:
        self.proc = await asyncio.create_subprocess_exec(
            adbmod.ADB, "-s", adbmod.serial(self.ip), "shell",
            stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL, env=adbmod.ENV)

    async def close(self) -> None:
        if self.task:
            self.task.cancel()
        if self.proc and self.proc.returncode is None:
            try:
                self.proc.terminate()
            except ProcessLookupError:
                pass

    # ---- API công khai (không chặn) ----
    def _put(self, item: tuple) -> None:
        try:
            self.q.put_nowait(item)
        except asyncio.QueueFull:
            if item[0] != "touch" or item[1] != "move":
                try:
                    self.q.get_nowait()
                    self.q.put_nowait(item)
                except (asyncio.QueueEmpty, asyncio.QueueFull):
                    pass

    def touch(self, action: str, pid: int, x: float, y: float) -> None:
        if 0 <= pid < MAX_FINGERS:
            self._put(("touch", action, pid, x, y))

    def key(self, k) -> bool:
        code = resolve_key(k)
        if code is None:
            return False
        self._put(("key", code))
        return True

    def text(self, s: str) -> bool:
        cmd = render_text(s, self.unicode_ok)
        if cmd is None:
            return False
        if cmd:
            self._put(("raw", cmd))
        return True

    def scroll(self, x: float, y: float, dy: float) -> None:
        now = time.monotonic()
        if now - self._last_scroll < 0.15:
            return
        self._last_scroll = now
        self._put(("scroll", x, y, dy))

    def release_all(self) -> None:
        for pid in list(self.active):
            self._put(("touch", "up", pid, 0.0, 0.0))

    # ---- worker: gom lô và ghi vào shell ----
    async def _worker(self) -> None:
        while True:
            batch = [await self.q.get()]
            await asyncio.sleep(0.008)
            while not self.q.empty():
                batch.append(self.q.get_nowait())
            lines = [r for r in (self._render(ev) for ev in self._coalesce(batch)) if r]
            if lines:
                await self._write("\n".join(lines))

    @staticmethod
    def _coalesce(batch: list) -> list:
        out = []
        for i, ev in enumerate(batch):
            if ev[0] == "touch" and ev[1] == "move":
                if any(b[0] == "touch" and b[2] == ev[2] for b in batch[i + 1:]):
                    continue
            out.append(ev)
        return out

    async def _write(self, script: str) -> None:
        try:
            if self.proc is None or self.proc.returncode is not None:
                await asyncio.to_thread(adbmod.ensure_connected, self.ip)
                await self._spawn()
            self.proc.stdin.write((script + "\n").encode())
            await self.proc.stdin.drain()
            self.last_error = None
        except (BrokenPipeError, ConnectionResetError, OSError) as exc:
            log.warning("shell write failed: %s", exc)
            self.last_error = f"Không gửi được lệnh điều khiển tới Android: {exc}"
            self.proc = None

    def _render(self, ev: tuple) -> str:
        kind = ev[0]
        if kind == "touch":
            return self._r_touch(*ev[1:]) if self.profile else self._r_touch_fb(*ev[1:])
        if kind == "key":
            return f"input keyevent {ev[1]}"
        if kind == "raw":
            return ev[1]
        if kind == "scroll":
            _, x, y, dy = ev
            px, py = int(x * (self.w - 1)), int(y * (self.h - 1))
            dist = int(min(abs(dy) * 2, 0.35 * self.h))
            if dist < 20:
                return ""
            py2 = max(0, min(self.h - 1, py - dist if dy > 0 else py + dist))
            return f"input swipe {px} {py} {px} {py2} 160"
        return ""

    def _next_tid(self) -> int:
        self._tid = (self._tid + 1) % 60000
        return self._tid

    def _r_touch(self, action: str, pid: int, nx: float, ny: float) -> str:
        p = self.profile
        if pid >= p.slots:
            return ""
        X, Y = int(nx * p.xmax), int(ny * p.ymax)
        ev: List[str] = []

        def e(t: int, c: int, v: int) -> None:
            ev.append(f"sendevent {p.path} {t} {c} {v}")

        if action == "down":
            if pid in self.active:
                action = "move"
            else:
                tid = self._next_tid()
                self.active[pid] = tid
                e(EV_ABS, ABS_MT_SLOT, pid)
                e(EV_ABS, ABS_MT_TRACKING_ID, tid)
                e(EV_ABS, ABS_MT_POSITION_X, X)
                e(EV_ABS, ABS_MT_POSITION_Y, Y)
                for code in (ABS_MT_PRESSURE, ABS_MT_TOUCH_MAJOR):
                    if code in p.abs:
                        e(EV_ABS, code, max(1, p.abs[code][1] // 4))
                if len(self.active) == 1:
                    e(EV_KEY, BTN_TOUCH, 1)
                e(EV_SYN, 0, 0)
        if action == "move":
            if pid not in self.active:
                return ""
            e(EV_ABS, ABS_MT_SLOT, pid)
            e(EV_ABS, ABS_MT_POSITION_X, X)
            e(EV_ABS, ABS_MT_POSITION_Y, Y)
            e(EV_SYN, 0, 0)
        elif action in ("up", "cancel"):
            if pid not in self.active:
                return ""
            del self.active[pid]
            e(EV_ABS, ABS_MT_SLOT, pid)
            e(EV_ABS, ABS_MT_TRACKING_ID, -1)
            if not self.active:
                e(EV_KEY, BTN_TOUCH, 0)
            e(EV_SYN, 0, 0)
        return "; ".join(ev)

    def _r_touch_fb(self, action: str, pid: int, nx: float, ny: float) -> str:
        x, y = int(nx * (self.w - 1)), int(ny * (self.h - 1))
        if action == "down":
            self.fb[pid] = [x, y, time.monotonic(), x, y]
            return ""
        st = self.fb.get(pid)
        if st is None:
            return ""
        if action == "move":
            st[3], st[4] = x, y
            return ""
        del self.fb[pid]
        if action == "cancel":
            return ""
        x0, y0, t0, x1, y1 = st
        ms = int((time.monotonic() - t0) * 1000)
        if abs(x1 - x0) + abs(y1 - y0) < 12:
            if ms < 450:
                return f"input tap {x0} {y0}"
            return f"input swipe {x0} {y0} {x0} {y0} {min(ms, 3000)}"
        return f"input swipe {x0} {y0} {x1} {y1} {max(60, min(ms, 1500))}"
