"""Quản lý vòng đời container redroid (Android thật) bằng Docker."""
import re
import secrets
import threading
from concurrent.futures import ThreadPoolExecutor
from typing import List, Optional

import docker
from docker.errors import APIError, ImageNotFound, NotFound
from docker.types import LogConfig

import adb as adbmod
import config

_client = None
_ready: dict = {}              # (container id, StartedAt) -> True khi Android đã boot xong
_provisioning: set = set()
_pool = ThreadPoolExecutor(max_workers=8)
_ID = re.compile(r"^[a-f0-9]{6,64}$")


class DeviceError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status


def client():
    global _client
    if _client is None:
        _client = docker.from_env()
    return _client


def safe_name(value: str) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9_-]", "-", value).strip("-")[:30]
    return cleaned or "android-cloud"


def ensure_network() -> None:
    c = client()
    try:
        c.networks.get(config.NETWORK)
    except NotFound:
        c.networks.create(config.NETWORK, driver="bridge", labels={config.LABEL_KEY: "true"})


_docker_err: Optional[str] = None


def docker_ok() -> bool:
    global _docker_err, _client
    try:
        client().ping()
        _docker_err = None
        return True
    except Exception as exc:  # noqa: BLE001
        _docker_err = str(exc)[:300] or exc.__class__.__name__
        _client = None            # thử tạo lại client ở lần gọi sau (Docker có thể vừa được bật)
        return False


def docker_error() -> Optional[str]:
    return _docker_err


def _is_ours(c) -> bool:
    return c.labels.get(config.LABEL_KEY) == "true"


def _can_access(c, user) -> bool:
    return user["role"] == "admin" or c.labels.get(config.OWNER_LABEL) == str(user["id"])


def get_owned(device_id: str, user):
    if not _ID.match(device_id or ""):
        raise DeviceError(404, "Device not found.")
    try:
        c = client().containers.get(device_id)
    except NotFound:
        raise DeviceError(404, "Device not found.")
    except APIError as exc:
        raise DeviceError(503, str(exc))
    if not _is_ours(c) or not _can_access(c, user):
        raise DeviceError(404, "Device not found.")
    return c


def ip_of(c) -> Optional[str]:
    nets = (c.attrs.get("NetworkSettings") or {}).get("Networks") or {}
    return (nets.get(config.NETWORK) or {}).get("IPAddress") or None


def is_ready(c) -> bool:
    if c.status != "running":
        return False
    key = (c.id, (c.attrs.get("State") or {}).get("StartedAt", ""))
    if _ready.get(key):
        return True
    ip = ip_of(c)
    if ip and adbmod.boot_completed(ip):
        _ready[key] = True
        if key not in _provisioning:  # cài APK/IME một lần, không chặn request
            _provisioning.add(key)
            threading.Thread(target=_provision, args=(key, ip), daemon=True).start()
        return True
    return False


def _provision(key, ip) -> None:
    try:
        adbmod.provision(ip)
    finally:
        _provisioning.discard(key)


def list_platforms() -> List[dict]:
    return [{"key": k, "label": p["label"], "android": p["android"], "default": k == config.DEFAULT_PLATFORM}
            for k, p in config.PLATFORMS.items()]


def _problem(c, ready: Optional[bool]) -> Optional[str]:
    """Lý do thật khiến thiết bị chưa dùng được (None nếu bình thường)."""
    st = c.attrs.get("State") or {}
    if c.status == "running":
        if ready:
            return None
        ip = ip_of(c)
        if not ip:
            return f"Container chạy nhưng chưa có IP trong mạng {config.NETWORK}."
        return adbmod.LAST_ERR.get(ip) or "Android đang khởi động."
    if st.get("OOMKilled"):
        return "Container bị dừng vì hết bộ nhớ (OOM). Tăng DEVICE_MEMORY."
    code = st.get("ExitCode")
    if c.status in ("exited", "dead") and code not in (None, 0):
        return f"Container thoát với mã {code}" + (f": {st.get('Error')}" if st.get("Error") else
                                                    ". Xem mục Chẩn đoán để đọc log (thường do kernel thiếu binder_linux).")
    if c.status == "restarting":
        return "Container đang khởi động lại liên tục. Xem mục Chẩn đoán để đọc log."
    return None


def info(c, ready: Optional[bool] = None) -> dict:
    cfg = c.attrs.get("Config") or {}
    plat = config.PLATFORMS.get(c.labels.get(config.PLATFORM_LABEL, ""))
    return {
        "error": _problem(c, ready),
        "platform": c.labels.get(config.PLATFORM_LABEL),
        "platform_label": plat["label"] if plat else None,
        "android": plat["android"] if plat else None,
        "id": c.short_id,
        "name": c.name,
        "status": c.status,
        "image": cfg.get("Image") or config.IMAGE,
        "ready": bool(ready),
        "owner": c.labels.get(config.OWNER_LABEL),
        "created": c.attrs.get("Created"),
    }


def _all(user) -> List:
    cs = client().containers.list(all=True, filters={"label": f"{config.LABEL_KEY}=true"})
    return [c for c in cs if _can_access(c, user)]


def list_devices(user) -> List[dict]:
    try:
        cs = _all(user)
        readies = list(_pool.map(is_ready, cs))
        return [info(c, r) for c, r in zip(cs, readies)]
    except APIError as exc:
        raise DeviceError(503, f"Docker is unavailable: {exc}")
    except Exception as exc:  # noqa: BLE001
        raise DeviceError(503, f"Docker is unavailable: {exc}")


def get_info(device_id: str, user) -> dict:
    c = get_owned(device_id, user)
    return info(c, is_ready(c))


def create(name: str, user, platform: Optional[str] = None) -> dict:
    platform = (platform or config.DEFAULT_PLATFORM).lower()
    plat = config.PLATFORMS.get(platform)
    if not plat:
        raise DeviceError(400, "Loại thiết bị không hợp lệ.")
    image = plat["image"]
    try:
        allc = client().containers.list(all=True, filters={"label": f"{config.LABEL_KEY}=true"})
        mine = [c for c in allc if c.labels.get(config.OWNER_LABEL) == str(user["id"])]
        if len(allc) >= config.DEVICE_LIMIT:
            raise DeviceError(409, f"Device limit reached ({config.DEVICE_LIMIT}).")
        if user["role"] != "admin" and len(mine) >= config.PER_USER_LIMIT:
            raise DeviceError(409, f"Per-user device limit reached ({config.PER_USER_LIMIT}).")
        ensure_network()
        base = f"shadow-{safe_name(name).lower()}"
        cname = base
        try:
            client().containers.get(cname)
            cname = f"{base}-{secrets.token_hex(2)}"
        except NotFound:
            pass
        args = [
            f"androidboot.redroid_width={config.ANDROID_WIDTH}",
            f"androidboot.redroid_height={config.ANDROID_HEIGHT}",
            f"androidboot.redroid_dpi={config.ANDROID_DPI}",
            f"androidboot.redroid_fps={config.ANDROID_FPS}",
            "androidboot.redroid_gpu_mode=guest",
            "androidboot.use_memfd=true",   # Kernel Ubuntu 24.04 không có ashmem
            *config.REDROID_EXTRA_ARGS,
        ]
        # redroid cần privileged + binder trên kernel máy chủ. Cổng ADB 5555 KHÔNG được publish ra ngoài.
        container = client().containers.run(
            image, command=args, name=cname, detach=True, privileged=True, shm_size="1g",
            network=config.NETWORK, hostname=cname,
            mem_limit=config.DEVICE_MEMORY, memswap_limit=config.DEVICE_MEMORY,
            nano_cpus=int(config.DEVICE_CPUS * 1e9), pids_limit=2048,
            volumes={f"{cname}-data": {"bind": "/data", "mode": "rw"}},
            labels={config.LABEL_KEY: "true", config.OWNER_LABEL: str(user["id"]), config.PLATFORM_LABEL: platform},
            restart_policy={"Name": "unless-stopped"},
            log_config=LogConfig(type="json-file", config={"max-size": "10m", "max-file": "2"}),
        )
        return {"id": container.short_id, "name": container.name, "status": container.status}
    except DeviceError:
        raise
    except ImageNotFound:
        raise DeviceError(404, f"Image not found: {image}")
    except APIError as exc:
        raise DeviceError(503, f"Could not create Android container: {exc}")


def do_action(c, action: str) -> dict:
    try:
        getattr(c, action)()
        c.reload()
        return {"id": c.short_id, "name": c.name, "status": c.status}
    except APIError as exc:
        raise DeviceError(503, str(exc))


def delete(c) -> None:
    name = c.name
    try:
        c.remove(force=True)
        try:
            client().volumes.get(f"{name}-data").remove(force=True)
        except NotFound:
            pass
    except APIError as exc:
        raise DeviceError(503, str(exc))


def diagnose(c) -> List[dict]:
    """Chẩn đoán từng tầng cho một thiết bị: Docker -> container -> mạng -> ADB -> ảnh -> video -> cảm ứng."""
    steps: List[dict] = []
    ok_docker = docker_ok()
    steps.append({"id": "docker", "label": "Docker", "ok": ok_docker,
                  "detail": "Docker Engine phản hồi." if ok_docker else f"Không kết nối được Docker: {_docker_err}", "ms": 0})
    try:
        c.reload()
    except Exception as exc:  # noqa: BLE001
        steps.append({"id": "container", "label": "Container Android", "ok": False, "detail": f"Không đọc được container: {exc}", "ms": 0})
        return steps
    st = c.attrs.get("State") or {}
    if c.status != "running":
        detail = f"Trạng thái Docker: {c.status}."
        if st.get("ExitCode") not in (None, 0):
            detail += f" Mã thoát {st.get('ExitCode')}."
        if st.get("OOMKilled"):
            detail += " Bị dừng do hết bộ nhớ (OOM)."
        if st.get("Error"):
            detail += f" {st.get('Error')}"
        try:
            tail = c.logs(tail=8).decode("utf-8", "replace").strip().splitlines()
            if tail:
                detail += " Log cuối: " + " | ".join(l.strip()[:160] for l in tail[-4:])
        except Exception:  # noqa: BLE001
            pass
        steps.append({"id": "container", "label": "Container Android", "ok": False, "detail": detail, "ms": 0})
        return steps
    started = st.get("StartedAt", "")
    steps.append({"id": "container", "label": "Container Android", "ok": True,
                  "detail": f"Đang chạy (image {(c.attrs.get('Config') or {}).get('Image')}, khởi động {started[:19]}).", "ms": 0})
    ip = ip_of(c)
    if not ip:
        steps.append({"id": "network", "label": f"Mạng {config.NETWORK}", "ok": False,
                      "detail": "Container chưa có địa chỉ IP trong mạng nội bộ nên API không thể kết nối ADB.", "ms": 0})
        return steps
    steps.append({"id": "network", "label": f"Mạng {config.NETWORK}", "ok": True, "detail": f"IP {ip}", "ms": 0})
    steps.extend(adbmod.diagnose(ip))
    return steps
