"""Truyền màn hình Android thật qua WebRTC.

Luồng dữ liệu:
  redroid --(adb exec-out screenrecord, H.264)--> PyAV giải mã --> khung hình mới nhất
          --> aiortc mã hóa lại (H.264/VP8) --> WebRTC tới từng trình duyệt
  trình duyệt --(DataChannel "control")--> InputInjector --> adb shell --> Android
"""
import asyncio
import fractions
import json
import logging
import math
import subprocess
import threading
import time
import uuid
from collections import deque
from typing import Dict, Optional

import av
import numpy as np
from aiortc import (MediaStreamTrack, RTCConfiguration, RTCIceServer,
                    RTCPeerConnection, RTCRtpSender, RTCSessionDescription)
from aiortc.mediastreams import MediaStreamError

import adb as adbmod
import config
import ice
from inputs import InputInjector

log = logging.getLogger("shadow.stream")

# Giới hạn bitrate của bộ mã hóa aiortc (đọc lại ở mỗi lần đặt target_bitrate).
try:
    from aiortc.codecs import h264 as _h264, vpx as _vpx
    for _m in (_h264, _vpx):
        _m.MAX_BITRATE = config.MAX_VIDEO_BITRATE
        _m.DEFAULT_BITRATE = min(config.DEFAULT_VIDEO_BITRATE, config.MAX_VIDEO_BITRATE)
except Exception:  # pragma: no cover
    log.warning("Không thể đặt giới hạn bitrate cho bộ mã hóa")

# (chiều rộng, bitrate screenrecord, fps tối đa)
QUALITY = {"low": (360, 800_000, 15), "medium": (540, 2_000_000, 24), "high": (720, 4_000_000, 30)}
CLOCK = 90000
TIME_BASE = fractions.Fraction(1, CLOCK)


def scaled(w: int, h: int, target_w: int):
    tw = min(target_w, w)
    th = round(h * tw / w)
    return tw - tw % 2, th - th % 2


class ScreenSource:
    """Một tiến trình screenrecord + bộ giải mã cho mỗi thiết bị, chia sẻ cho mọi người xem."""

    def __init__(self, ip: str, native):
        self.ip, self.native = ip, native
        self.quality = "medium"
        self._lock = threading.Lock()
        self._frame: Optional[np.ndarray] = None
        self._seq = 0
        self._activity = time.monotonic()
        self._refs = 0
        self._idle_since = time.monotonic()
        self._thread: Optional[threading.Thread] = None
        self._stop: Optional[threading.Event] = None
        self._proc: Optional[subprocess.Popen] = None
        # Trạng thái thật của luồng hình (để báo lỗi chính xác cho người xem thay vì khung hình giả)
        self.state = "idle"                 # idle | starting | live | error
        self.last_error: Optional[str] = None
        self.frames = 0
        self.last_frame_at = 0.0
        self._run_started = time.monotonic()
        self._stderr: deque = deque(maxlen=6)

    def snapshot(self) -> dict:
        age = round(time.monotonic() - self.last_frame_at, 1) if self.last_frame_at else None
        return {"state": self.state, "error": self.last_error, "frames": self.frames, "last_frame_age_s": age,
                "quality": self.quality, "native": list(self.native)}

    def _drain_stderr(self, proc: subprocess.Popen) -> None:
        try:
            for raw in iter(proc.stderr.readline, b""):
                line = raw.decode("utf-8", "replace").strip()
                if line:
                    self._stderr.append(line[:200])
        except (OSError, ValueError):
            pass

    def _fail(self, why: str) -> None:
        tail = " | ".join(self._stderr)
        self.last_error = why + (f" ({tail})" if tail else "")
        self.state = "error"

    # ---- quản lý số người xem ----
    def acquire(self) -> None:
        with self._lock:
            self._refs += 1
            if self._thread is None or not self._thread.is_alive() or self._stop.is_set():
                self._stop = threading.Event()
                self._thread = threading.Thread(target=self._run, args=(self._stop,), daemon=True,
                                                name=f"screen-{self.ip}")
                self._thread.start()

    def release(self) -> None:
        with self._lock:
            self._refs = max(0, self._refs - 1)
            if self._refs == 0:
                self._idle_since = time.monotonic()

    def shutdown(self) -> None:
        with self._lock:
            if self._stop:
                self._stop.set()
        self._kill()

    def set_quality(self, q: str) -> None:
        if q in QUALITY and q != self.quality:
            self.quality = q
            self._kill()  # vòng lặp sẽ khởi động lại với tham số mới

    def latest(self):
        with self._lock:
            return self._frame, self._seq

    def fps_cap(self) -> int:
        return QUALITY[self.quality][2]

    def frame_size(self):
        w, h = scaled(*self.native, QUALITY[self.quality][0])
        return w, h

    def _kill(self) -> None:
        p = self._proc
        if p and p.poll() is None:
            try:
                p.kill()
            except OSError:
                pass

    # ---- luồng giải mã ----
    def _watchdog(self, stop: threading.Event) -> None:
        while not stop.wait(2.0):
            now = time.monotonic()
            with self._lock:
                idle = self._refs == 0 and now - self._idle_since > config.STREAM_IDLE_STOP
            if idle:
                log.info("screen %s: không còn người xem, dừng quay", self.ip)
                stop.set()
                self._kill()
                return
            if self.frames == 0 and now - self._run_started > 10 and self.state != "error":
                self._fail("Android không trả về hình ảnh sau 10 giây (screenrecord không xuất dữ liệu)")
            if now - self._activity > 20:  # treo: không có dữ liệu
                log.warning("screen %s: không có dữ liệu 20s, khởi động lại", self.ip)
                self._activity = now
                self._kill()

    def _run(self, stop: threading.Event) -> None:
        self._run_started = time.monotonic()
        self.state, self.last_error = "starting", None
        threading.Thread(target=self._watchdog, args=(stop,), daemon=True).start()
        backoff = 1.0
        while not stop.is_set():
            got_frame = False
            self._stderr.clear()
            try:
                if not adbmod.ensure_connected(self.ip):
                    raise ConnectionError(adbmod.LAST_ERR.get(self.ip) or "ADB không kết nối được")
                adbmod.prepare_screen(self.ip)
                w, h = self.frame_size()
                _, bitrate, _ = QUALITY[self.quality]
                cmd = [adbmod.ADB, "-s", adbmod.serial(self.ip), "exec-out", "screenrecord",
                       "--output-format=h264", "--size", f"{w}x{h}", "--bit-rate", str(bitrate),
                       "--time-limit", "180", "-"]
                self._proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                              bufsize=0, env=adbmod.ENV)
                threading.Thread(target=self._drain_stderr, args=(self._proc,), daemon=True).start()
                self._activity = time.monotonic()
                container = av.open(self._proc.stdout, format="h264", mode="r",
                                    options={"probesize": "65536", "analyzeduration": "0",
                                             "fflags": "nobuffer+discardcorrupt"})
                for frame in container.decode(video=0):
                    arr = frame.to_ndarray(format="yuv420p")
                    with self._lock:
                        self._frame = arr
                        self._seq += 1
                    self._activity = self.last_frame_at = time.monotonic()
                    self.frames += 1
                    self.state, self.last_error = "live", None
                    got_frame = True
                    if stop.is_set():
                        break
                container.close()
            except Exception as exc:  # noqa: BLE001
                if not stop.is_set():
                    log.warning("screen %s: %s", self.ip, exc)
                    if not got_frame:
                        self._fail(str(exc) or exc.__class__.__name__)
            finally:
                self._kill()
            if stop.is_set():
                break
            if not got_frame and self.state != "error":
                self._fail("screenrecord kết thúc mà không có hình")
            # screenrecord tự kết thúc sau 180s: khởi động lại ngay; lỗi thật thì lùi dần.
            backoff = 0.2 if got_frame else min(backoff * 2, 10.0)
            stop.wait(backoff)


class AndroidVideoTrack(MediaStreamTrack):
    """Phát khung hình mới nhất. Màn hình tĩnh thì hạ xuống 5 fps để tiết kiệm CPU."""
    kind = "video"

    def __init__(self, src: ScreenSource):
        super().__init__()
        self.src = src
        self._seq = -1
        self._last_change = time.monotonic()
        self._start: Optional[float] = None
        self._ts = 0
        self._last: Optional[np.ndarray] = None

    async def recv(self):
        if self.readyState != "live":
            raise MediaStreamError
        arr, seq = self.src.latest()
        while arr is None:           # chưa có hình thật từ Android: chờ, TUYỆT ĐỐI không phát khung giả
            if self.readyState != "live":
                raise MediaStreamError
            await asyncio.sleep(0.1)
            arr, seq = self.src.latest()
        now = time.monotonic()
        if seq != self._seq:
            self._seq, self._last_change = seq, now
        interval = 1.0 / self.src.fps_cap() if now - self._last_change < 1.0 else 0.2
        if self._start is None:
            self._start = time.time()
        else:
            self._ts += int(interval * CLOCK)
            await asyncio.sleep(max(0.0, self._start + self._ts / CLOCK - time.time()))
        frame = av.VideoFrame.from_ndarray(arr, format="yuv420p")
        frame.pts, frame.time_base = self._ts, TIME_BASE
        return frame


class SessionLimit(Exception):
    pass


class Session:
    def __init__(self, sid, user_id, dev_key, pc, src, injector):
        self.id, self.user_id, self.dev_key = sid, user_id, dev_key
        self.pc, self.src, self.injector = pc, src, injector
        self.channel = None
        self.closed = False
        self.created = time.time()
        self.tokens, self.t_refill = 1000.0, time.monotonic()
        self.warned = False


class StreamManager:
    def __init__(self):
        self.sources: Dict[str, ScreenSource] = {}
        self.injectors: Dict[str, InputInjector] = {}
        self.ips: Dict[str, str] = {}
        self.sessions: Dict[str, Session] = {}
        self._locks: Dict[str, asyncio.Lock] = {}

    async def _ensure_device(self, key: str, ip: str):
        lock = self._locks.setdefault(key, asyncio.Lock())
        async with lock:
            if self.ips.get(key) != ip:
                await self.close_device(key)
            if key not in self.sources:
                if not await asyncio.to_thread(adbmod.ensure_connected, ip):
                    raise ConnectionError("Không kết nối được ADB tới Android.")
                size = await asyncio.to_thread(adbmod.screen_size, ip)
                await asyncio.to_thread(adbmod.prepare_screen, ip)
                inj = InputInjector(ip, *size)
                await inj.start()
                self.sources[key] = ScreenSource(ip, size)
                self.injectors[key] = inj
                self.ips[key] = ip
            return self.sources[key], self.injectors[key]

    async def close_device(self, key: str) -> None:
        for s in [s for s in self.sessions.values() if s.dev_key == key]:
            await self.close_session(s.id)
        src, inj = self.sources.pop(key, None), self.injectors.pop(key, None)
        self.ips.pop(key, None)
        if src:
            src.shutdown()
        if inj:
            await inj.close()

    async def close_session(self, sid: str) -> None:
        s = self.sessions.pop(sid, None)
        if not s or s.closed:
            return
        s.closed = True
        s.injector.release_all()
        s.src.release()
        try:
            await s.pc.close()
        except Exception:  # noqa: BLE001
            pass

    def describe(self, key: str) -> dict:
        src, inj = self.sources.get(key), self.injectors.get(key)
        return {"sessions": sum(1 for x in self.sessions.values() if x.dev_key == key),
                "source": src.snapshot() if src else None,
                "input": {"mode": inj.mode, "unicode": inj.unicode_ok, "error": inj.last_error} if inj else None}

    async def close_all(self) -> None:
        for key in list(self.sources):
            await self.close_device(key)

    # ---- tạo phiên WebRTC ----
    async def open(self, dev_key: str, ip: str, user, offer_sdp: str, quality: str,
                   replace: Optional[str] = None) -> dict:
        uid = user["id"]
        if replace:
            old = self.sessions.get(replace)
            if old and old.user_id == uid:
                await self.close_session(replace)
        mine = sorted((s for s in self.sessions.values() if s.user_id == uid), key=lambda s: s.created)
        while len(mine) >= config.MAX_SESSIONS_PER_USER:
            await self.close_session(mine.pop(0).id)
        on_dev = [s for s in self.sessions.values() if s.dev_key == dev_key]
        if len(on_dev) >= config.MAX_SESSIONS_PER_DEVICE:
            raise SessionLimit("Thiết bị đang có quá nhiều người xem.")

        src, inj = await self._ensure_device(dev_key, ip)
        if quality in QUALITY:
            src.set_quality(quality)

        servers = [RTCIceServer(urls=config.STUN_URLS)]
        turn = ice.turn_credentials("server")
        if turn:
            servers.append(RTCIceServer(urls=turn["urls"], username=turn["username"],
                                        credential=turn["credential"]))
        pc = RTCPeerConnection(RTCConfiguration(iceServers=servers))
        sid = uuid.uuid4().hex
        sess = Session(sid, uid, dev_key, pc, src, inj)
        self.sessions[sid] = sess
        src.acquire()

        @pc.on("datachannel")
        def on_channel(channel):
            sess.channel = channel
            channel.on("message", lambda raw: self._on_message(sess, raw))

        @pc.on("connectionstatechange")
        async def on_state():
            state = pc.connectionState
            if state in ("failed", "closed"):
                await self.close_session(sid)
            elif state == "disconnected":
                await asyncio.sleep(20)
                if pc.connectionState == "disconnected":
                    await self.close_session(sid)

        try:
            await pc.setRemoteDescription(RTCSessionDescription(sdp=offer_sdp, type="offer"))
            pc.addTrack(AndroidVideoTrack(src))
            caps = RTCRtpSender.getCapabilities("video").codecs
            prefs = [c for c in caps if c.mimeType.lower() == "video/h264"] + \
                    [c for c in caps if c.mimeType.lower() == "video/vp8"]
            for t in pc.getTransceivers():
                if t.kind == "video" and prefs:
                    t.setCodecPreferences(prefs)
            await pc.setLocalDescription(await pc.createAnswer())
        except Exception:
            await self.close_session(sid)
            raise
        return {"sdp": pc.localDescription.sdp, "type": pc.localDescription.type, "session": sid,
                "input_mode": inj.mode, "unicode": inj.unicode_ok}

    # ---- kênh điều khiển ----
    def _on_message(self, s: Session, raw) -> None:
        now = time.monotonic()
        s.tokens = min(1000.0, s.tokens + (now - s.t_refill) * 500)
        s.t_refill = now
        if s.tokens < 1 or not isinstance(raw, str) or len(raw) > 2000:
            return
        s.tokens -= 1
        try:
            m = json.loads(raw)
        except ValueError:
            return
        if not isinstance(m, dict):
            return
        t, inj = m.get("t"), s.injector

        def num(v):
            return float(v) if isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) else None

        if t == "touch":
            x, y, pid = num(m.get("x")), num(m.get("y")), m.get("id")
            if m.get("a") in ("down", "move", "up", "cancel") and isinstance(pid, int) \
                    and x is not None and y is not None:
                inj.touch(m["a"], pid, min(1.0, max(0.0, x)), min(1.0, max(0.0, y)))
        elif t == "key":
            inj.key(m.get("k"))
        elif t == "text":
            v = m.get("s")
            if isinstance(v, str) and not inj.text(v) and not s.warned and s.channel:
                s.warned = True
                s.channel.send(json.dumps({"t": "warn", "m": "Cần cài ADBKeyboard để gõ ký tự Unicode/tiếng Việt."}))
        elif t == "scroll":
            x, y, dy = num(m.get("x")), num(m.get("y")), num(m.get("dy"))
            if None not in (x, y, dy):
                inj.scroll(min(1.0, max(0.0, x)), min(1.0, max(0.0, y)), dy)
        elif t == "quality":
            if m.get("q") in QUALITY:
                s.src.set_quality(m["q"])
        elif t == "ping" and s.channel:
            s.channel.send(json.dumps({"t": "pong", "ts": m.get("ts"), "s": s.src.state, "e": s.src.last_error,
                                       "i": s.injector.last_error}))


manager = StreamManager()


def runtime_info() -> dict:
    """Thư viện WebRTC/video thực tế đang dùng (để báo lỗi chính xác nếu thiếu bộ mã hóa)."""
    try:
        codecs = set(av.codecs_available)
    except Exception:  # noqa: BLE001
        codecs = set()
    return {"aiortc": getattr(__import__("aiortc"), "__version__", "?"), "av": getattr(av, "__version__", "?"),
            "h264_encoder": "libx264" in codecs, "h264_decoder": "h264" in codecs, "vp8_encoder": "libvpx" in codecs}
