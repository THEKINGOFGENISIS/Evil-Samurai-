"""Cấu hình trung tâm của Shadow Cloud Phone (đọc từ biến môi trường)."""
import os
import secrets
from pathlib import Path

VERSION = "0.6.0"


def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except ValueError:
        return default


def _float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, str(default)))
    except ValueError:
        return default


def _bool(name: str, default: str = "0") -> bool:
    return os.getenv(name, default).strip().lower() in ("1", "true", "yes", "on")


def _list(name: str) -> list:
    return [x.strip() for x in os.getenv(name, "").split(",") if x.strip()]


DATA_DIR = Path(os.getenv("DATA_DIR", "/data"))
try:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    (DATA_DIR / "home").mkdir(exist_ok=True)
except OSError:
    pass

# --- Thiết bị Android (redroid) ---
# Danh mục nền tảng (platform) người dùng được chọn khi tạo máy. Muốn thêm loại mới: thêm 1 dòng vào đây
# (hoặc đổi image bằng biến môi trường IMAGE_<TÊN>). key = chữ thường, không dấu cách.
# Tên Typhoon/Universe/Voyager là nhánh BlissOS (Android 13/14/15); máy chạy bằng image redroid tương ứng.
PLATFORMS = {
    "typhoon":  {"label": "Typhoon",  "android": "13", "image": os.getenv("IMAGE_TYPHOON",  "redroid/redroid:13.0.0-latest")},
    "universe": {"label": "Universe", "android": "14", "image": os.getenv("IMAGE_UNIVERSE", "redroid/redroid:14.0.0-latest")},
    "voyager":  {"label": "Voyager",  "android": "15", "image": os.getenv("IMAGE_VOYAGER",  "redroid/redroid:15.0.0-latest")},
}
DEFAULT_PLATFORM = os.getenv("DEFAULT_PLATFORM", "typhoon")
if DEFAULT_PLATFORM not in PLATFORMS:
    DEFAULT_PLATFORM = next(iter(PLATFORMS))
IMAGE = PLATFORMS[DEFAULT_PLATFORM]["image"]      # giữ để tương thích code cũ
DEVICE_LIMIT = _int("DEVICE_LIMIT", 1)            # tổng số thiết bị trên máy chủ
PER_USER_LIMIT = _int("PER_USER_LIMIT", 1)        # số thiết bị mỗi người dùng thường
LABEL_KEY = "shadow-cloud-phone"
OWNER_LABEL = "shadow-owner"
PLATFORM_LABEL = "shadow-platform"
NETWORK = os.getenv("DEVICE_NETWORK", "shadow-net")
ANDROID_WIDTH = _int("ANDROID_WIDTH", 720)
ANDROID_HEIGHT = _int("ANDROID_HEIGHT", 1280)
ANDROID_DPI = _int("ANDROID_DPI", 320)
ANDROID_FPS = _int("ANDROID_FPS", 30)
DEVICE_MEMORY = os.getenv("DEVICE_MEMORY", "3g")
DEVICE_CPUS = _float("DEVICE_CPUS", 2.0)
REDROID_EXTRA_ARGS = os.getenv("REDROID_EXTRA_ARGS", "").split()
APK_DIR = Path(os.getenv("APK_DIR", "/apks"))

# --- Xác thực / bảo mật ---
ACCESS_TTL = _int("ACCESS_TOKEN_MINUTES", 15) * 60
REFRESH_TTL = _int("REFRESH_TOKEN_DAYS", 7) * 86400
COOKIE_SECURE = _bool("COOKIE_SECURE", "1")
ALLOWED_ORIGINS = _list("ALLOWED_ORIGINS")
ENABLE_DOCS = _bool("ENABLE_DOCS", "0")
ALLOW_REGISTER = _bool("ALLOW_REGISTER", "0")      # cho phép tự đăng ký (vai trò user)
RATE_LIMIT_PER_MIN = _int("RATE_LIMIT_PER_MIN", 600)
TRUSTED_PROXIES = _list("TRUSTED_PROXIES") or ["127.0.0.1", "::1"]
ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "")


def load_jwt_secret() -> str:
    env = os.getenv("JWT_SECRET", "").strip()
    if len(env) >= 32:
        return env
    path = DATA_DIR / "jwt.secret"
    try:
        if path.exists():
            return path.read_text().strip()
        value = secrets.token_urlsafe(48)
        path.write_text(value)
        path.chmod(0o600)
        return value
    except OSError:
        return secrets.token_urlsafe(48)  # tạm thời, token mất hiệu lực khi khởi động lại


JWT_SECRET = load_jwt_secret()

# --- WebRTC ---
STUN_URLS = _list("STUN_URLS") or ["stun:stun.l.google.com:19302"]
TURN_URLS = _list("TURN_URLS")            # ví dụ: turn:phone.example.com:3478
TURN_SECRET = os.getenv("TURN_SECRET", "")
TURN_TTL = _int("TURN_TTL", 3600)
ICE_FORCE_RELAY = _bool("ICE_FORCE_RELAY", "0")
MAX_SESSIONS_PER_DEVICE = _int("MAX_SESSIONS_PER_DEVICE", 2)
MAX_SESSIONS_PER_USER = _int("MAX_SESSIONS_PER_USER", 3)
STREAM_IDLE_STOP = _int("STREAM_IDLE_STOP", 20)     # giây: dừng quay màn hình khi không còn người xem
MAX_VIDEO_BITRATE = _int("MAX_VIDEO_BITRATE", 4_000_000)
DEFAULT_VIDEO_BITRATE = _int("DEFAULT_VIDEO_BITRATE", 2_000_000)
