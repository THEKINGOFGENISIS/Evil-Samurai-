import asyncio
import logging
import re
from contextlib import asynccontextmanager
from typing import Literal, Optional
from urllib.parse import urlparse

from fastapi import Depends, FastAPI, HTTPException, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from starlette.concurrency import run_in_threadpool as bg

import adb as adbmod
import auth
import config
import devices as dm
import ice
from stream import SessionLimit, manager, runtime_info

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("shadow")


@asynccontextmanager
async def lifespan(_: FastAPI):
    auth.init()
    try:
        await bg(dm.ensure_network)
    except Exception as exc:  # noqa: BLE001
        log.warning("Chưa tạo được mạng Docker: %s", exc)
    yield
    await manager.close_all()


app = FastAPI(title="Shadow Cloud Phone API", version=config.VERSION, lifespan=lifespan,
              docs_url="/docs" if config.ENABLE_DOCS else None, redoc_url=None,
              openapi_url="/openapi.json" if config.ENABLE_DOCS else None)

if config.ALLOWED_ORIGINS:
    app.add_middleware(CORSMiddleware, allow_origins=config.ALLOWED_ORIGINS, allow_credentials=True,
                       allow_methods=["GET", "POST", "DELETE"], allow_headers=["Authorization", "Content-Type",
                                                                               "X-Requested-With"])

rate = auth.RateLimiter(config.RATE_LIMIT_PER_MIN)
CSP = ("default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; style-src 'self' 'unsafe-inline'; "
       "script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")


def origin_ok(origin: str, request: Request) -> bool:
    return origin in config.ALLOWED_ORIGINS or urlparse(origin).netloc == request.headers.get("host")


@app.middleware("http")
async def guard(request: Request, call_next):
    ip = auth.client_ip(request)
    if request.url.path.startswith("/api") and not rate.allow(ip):
        return JSONResponse({"detail": "Quá nhiều yêu cầu, hãy thử lại sau."}, status_code=429)
    if request.method not in ("GET", "HEAD", "OPTIONS"):
        origin = request.headers.get("origin")
        if origin and not origin_ok(origin, request):
            return JSONResponse({"detail": "Origin không được phép."}, status_code=403)
    resp = await call_next(request)
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Referrer-Policy"] = "no-referrer"
    resp.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    if request.url.path.startswith("/api"):
        resp.headers["Cache-Control"] = "no-store"
    else:
        resp.headers["Content-Security-Policy"] = CSP
    return resp


def dev_call(fn, *a):
    async def run():
        try:
            return await bg(fn, *a)
        except dm.DeviceError as exc:
            raise HTTPException(exc.status, str(exc))
    return run()


# ------------------------------------------------------------------ sức khỏe
@app.get("/api/health")
async def health():
    return {"ok": True, "docker": await bg(dm.docker_ok), "version": config.VERSION, "register": config.ALLOW_REGISTER}


@app.get("/api/status")
async def status(_=Depends(auth.current_user)):
    """Trạng thái thật của từng thành phần backend (cần đăng nhập vì có chi tiết lỗi)."""
    docker = await bg(dm.docker_ok)
    adb_ok, adb_detail = await bg(adbmod.version)
    try:
        rt = runtime_info()
    except Exception as exc:  # noqa: BLE001
        rt = {"error": str(exc)}
    problems = []
    if not docker:
        problems.append(f"Docker: {dm.docker_error()}")
    if not adb_ok:
        problems.append(f"ADB: {adb_detail}")
    if rt.get("h264_encoder") is False and rt.get("vp8_encoder") is False:
        problems.append("WebRTC: thiếu bộ mã hóa video (libx264/libvpx) trong PyAV.")
    return {"ok": not problems, "version": config.VERSION, "mock": False, "docker": docker,
            "docker_error": dm.docker_error(), "adb": adb_ok, "adb_detail": adb_detail,
            "webrtc": rt, "problems": problems}


# ------------------------------------------------------------------ xác thực
class LoginBody(BaseModel):
    username: str = Field(min_length=1, max_length=64)
    password: str = Field(min_length=1, max_length=256)


def set_cookie(response: Response, refresh: str) -> None:
    response.set_cookie(auth.COOKIE, refresh, max_age=config.REFRESH_TTL, httponly=True,
                        secure=config.COOKIE_SECURE, samesite="strict", path="/api/auth")


@app.post("/api/auth/login")
async def login(body: LoginBody, request: Request, response: Response):
    ip = auth.client_ip(request)
    wait = auth.login_limiter.retry_after(ip, body.username)
    if wait:
        raise HTTPException(429, f"Đăng nhập sai quá nhiều lần. Thử lại sau {wait} giây.",
                            headers={"Retry-After": str(wait)})
    user = await bg(auth.authenticate, body.username, body.password)
    if not user:
        auth.login_limiter.fail(ip, body.username)
        await bg(auth.audit, body.username[:64], "login_failed", "", ip)
        raise HTTPException(401, "Sai tên đăng nhập hoặc mật khẩu.")
    auth.login_limiter.success(ip, body.username)
    access, refresh = await bg(auth.issue, user)
    set_cookie(response, refresh)
    await bg(auth.audit, user["username"], "login", "", ip)
    return {"access_token": access, "token_type": "bearer", "expires_in": config.ACCESS_TTL,
            "user": auth.public(user)}


class RegisterBody(BaseModel):
    username: str = Field(pattern=r"^[a-zA-Z0-9_.-]{3,32}$")
    password: str = Field(min_length=10, max_length=128)


reg_rate = auth.RateLimiter(5)   # tối đa 5 lần đăng ký/phút/IP


@app.post("/api/auth/register")
async def register(body: RegisterBody, request: Request):
    if not config.ALLOW_REGISTER:
        raise HTTPException(403, "Tự đăng ký tài khoản đang tắt.")
    ip = auth.client_ip(request)
    if not reg_rate.allow(ip):
        raise HTTPException(429, "Đăng ký quá nhanh, hãy thử lại sau.")
    try:
        await bg(auth.create_user, body.username, body.password, "user")   # luôn là user thường
    except Exception:  # noqa: BLE001
        raise HTTPException(409, "Tên đăng nhập đã tồn tại.")
    await bg(auth.audit, body.username, "register", "", ip)
    return {"ok": True, "username": body.username}


@app.post("/api/auth/refresh")
async def refresh(request: Request, response: Response):
    if request.headers.get("x-requested-with") != "shadow":
        raise HTTPException(403, "Thiếu header yêu cầu.")
    token = request.cookies.get(auth.COOKIE)
    if not token:
        raise HTTPException(401, "Chưa đăng nhập.")
    user, access, new_refresh = await bg(auth.rotate, token)
    set_cookie(response, new_refresh)
    return {"access_token": access, "token_type": "bearer", "expires_in": config.ACCESS_TTL,
            "user": auth.public(user)}


@app.post("/api/auth/logout")
async def logout(request: Request, response: Response):
    await bg(auth.revoke, request.cookies.get(auth.COOKIE))
    response.delete_cookie(auth.COOKIE, path="/api/auth")
    return {"ok": True}


@app.get("/api/auth/me")
async def me(user=Depends(auth.current_user)):
    return auth.public(user)


class PasswordBody(BaseModel):
    current: str = Field(min_length=1, max_length=256)
    new: str = Field(min_length=10, max_length=128)


@app.post("/api/auth/password")
async def change_password(body: PasswordBody, request: Request, user=Depends(auth.current_user)):
    if not await bg(auth.verify_password, body.current, user["pw_hash"]):
        raise HTTPException(400, "Mật khẩu hiện tại không đúng.")
    await bg(auth.set_password, user["id"], body.new)
    await bg(auth.audit, user["username"], "password_change", "", auth.client_ip(request))
    return {"ok": True}


# ------------------------------------------------------------------ người dùng (admin)
class NewUser(BaseModel):
    username: str = Field(pattern=r"^[a-zA-Z0-9_.-]{3,32}$")
    password: str = Field(min_length=10, max_length=128)
    role: Literal["user", "admin"] = "user"


@app.get("/api/users")
async def users(_=Depends(auth.require_admin)):
    return await bg(auth.list_users)


@app.post("/api/users")
async def add_user(body: NewUser, request: Request, admin=Depends(auth.require_admin)):
    try:
        uid = await bg(auth.create_user, body.username, body.password, body.role)
    except Exception:  # noqa: BLE001
        raise HTTPException(409, "Tên đăng nhập đã tồn tại.")
    await bg(auth.audit, admin["username"], "user_create", body.username, auth.client_ip(request))
    return {"id": uid, "username": body.username, "role": body.role}


@app.delete("/api/users/{uid}")
async def remove_user(uid: int, request: Request, admin=Depends(auth.require_admin)):
    target = await bg(auth.get_user, uid)
    if not target:
        raise HTTPException(404, "Không tìm thấy người dùng.")
    if target["id"] == admin["id"]:
        raise HTTPException(400, "Không thể tự xóa chính mình.")
    await bg(auth.delete_user, uid)
    await bg(auth.audit, admin["username"], "user_delete", target["username"], auth.client_ip(request))
    return {"deleted": uid}


@app.get("/api/audit")
async def audit_log(limit: int = 100, user=Depends(auth.current_user)):
    return await bg(auth.audit_list, user, limit)


# ------------------------------------------------------------------ thiết bị (chức năng gốc)
class CreateRequest(BaseModel):
    name: str = Field(default="Android Cloud", max_length=30)
    platform: Optional[str] = Field(default=None, max_length=32, pattern=r"^[a-z0-9_-]+$")


@app.get("/api/platforms")
async def platforms(_=Depends(auth.current_user)):
    return dm.list_platforms()


@app.get("/api/devices")
async def devices(user=Depends(auth.current_user)):
    return await dev_call(dm.list_devices, user)


@app.post("/api/devices")
async def create_device(body: CreateRequest, request: Request, user=Depends(auth.current_user)):
    res = await dev_call(dm.create, body.name, user, body.platform)
    await bg(auth.audit, user["username"], "device_create", res["name"], auth.client_ip(request))
    return res


@app.get("/api/devices/{device_id}")
async def device_detail(device_id: str, user=Depends(auth.current_user)):
    return await dev_call(dm.get_info, device_id, user)


@app.post("/api/devices/{device_id}/{action}")
async def device_action(device_id: str, action: str, request: Request, user=Depends(auth.current_user)):
    if action not in ("start", "stop", "restart"):
        raise HTTPException(400, "Action must be start, stop, or restart.")
    c = await dev_call(dm.get_owned, device_id, user)
    if action in ("stop", "restart"):
        await manager.close_device(c.id)
    res = await dev_call(dm.do_action, c, action)
    await bg(auth.audit, user["username"], f"device_{action}", c.name, auth.client_ip(request))
    return res


@app.delete("/api/devices/{device_id}")
async def delete_device(device_id: str, request: Request, user=Depends(auth.current_user)):
    c = await dev_call(dm.get_owned, device_id, user)
    await manager.close_device(c.id)
    await dev_call(dm.delete, c)
    await bg(auth.audit, user["username"], "device_delete", c.name, auth.client_ip(request))
    return {"deleted": device_id}


# ------------------------------------------------------------------ Open Device: WebRTC + ảnh chụp
@app.get("/api/webrtc/ice")
async def webrtc_ice(user=Depends(auth.current_user)):
    return ice.client_ice(user["username"])


class OfferBody(BaseModel):
    sdp: str = Field(max_length=30000)
    type: Literal["offer"]
    quality: Literal["low", "medium", "high"] = "medium"
    replace: Optional[str] = Field(default=None, max_length=64, pattern=r"^[a-f0-9]+$")


@app.post("/api/devices/{device_id}/webrtc/offer")
async def webrtc_offer(device_id: str, body: OfferBody, request: Request, user=Depends(auth.current_user)):
    c = await dev_call(dm.get_owned, device_id, user)
    if c.status != "running":
        raise HTTPException(409, "Thiết bị chưa chạy. Hãy nhấn Start.")
    ip = dm.ip_of(c)
    if not ip or not await bg(dm.is_ready, c):
        raise HTTPException(409, (adbmod.LAST_ERR.get(ip) if ip else None) or "Android đang khởi động, vui lòng đợi giây lát.")
    try:
        answer = await manager.open(c.id, ip, user, body.sdp, body.quality, body.replace)
    except SessionLimit as exc:
        raise HTTPException(429, str(exc))
    except ConnectionError as exc:
        raise HTTPException(503, str(exc))
    except Exception as exc:  # noqa: BLE001
        log.exception("webrtc offer failed")
        raise HTTPException(500, f"Không thể tạo phiên WebRTC: {exc}")
    await bg(auth.audit, user["username"], "device_open", c.name, auth.client_ip(request))
    return answer


@app.delete("/api/devices/{device_id}/webrtc/{session_id}")
async def webrtc_close(device_id: str, session_id: str, user=Depends(auth.current_user)):
    await dev_call(dm.get_owned, device_id, user)
    s = manager.sessions.get(session_id)
    if s and s.user_id == user["id"]:
        await manager.close_session(session_id)
    return {"closed": session_id}


@app.get("/api/devices/{device_id}/screenshot")
async def screenshot(device_id: str, user=Depends(auth.current_user)):
    c = await dev_call(dm.get_owned, device_id, user)
    ip = dm.ip_of(c)
    if c.status != "running" or not ip:
        raise HTTPException(409, "Thiết bị chưa chạy.")
    if not await bg(dm.is_ready, c):
        raise HTTPException(409, adbmod.LAST_ERR.get(ip) or "Android đang khởi động, chưa chụp được màn hình.")
    png, err = await bg(adbmod.screencap_png_ex, ip)
    if not png:
        raise HTTPException(503, err or "Không chụp được màn hình.")
    return Response(png, media_type="image/png",
                    headers={"Content-Disposition": f'attachment; filename="{re.sub(r"[^a-z0-9-]", "", c.name)}.png"'})


_diag_locks: dict = {}


@app.get("/api/devices/{device_id}/diagnostics")
async def diagnostics(device_id: str, user=Depends(auth.current_user)):
    """Chẩn đoán thật từng tầng (Docker → container → ADB → ảnh → H.264 → cảm ứng). Mất vài giây."""
    c = await dev_call(dm.get_owned, device_id, user)
    lock = _diag_locks.setdefault(c.id, asyncio.Lock())
    if lock.locked():
        raise HTTPException(429, "Đang có một lần chẩn đoán khác chạy cho thiết bị này.")
    async with lock:
        steps = await bg(dm.diagnose, c)
    failed = [x for x in steps if x["ok"] is False]
    return {"device": c.name, "ok": not failed and all(x["ok"] for x in steps),
            "summary": ("Tất cả kiểm tra đều đạt." if not failed else
                        f"Lỗi ở bước “{failed[0]['label']}”: {failed[0]['detail']}"),
            "steps": steps, "stream": manager.describe(c.id)}


# ------------------------------------------------------------------ giao diện web (cùng origin với API)
import os  # noqa: E402

_FRONT = os.getenv("FRONTEND_DIR", "/frontend")
if os.path.isdir(_FRONT):
    app.mount("/", StaticFiles(directory=_FRONT, html=True), name="web")
