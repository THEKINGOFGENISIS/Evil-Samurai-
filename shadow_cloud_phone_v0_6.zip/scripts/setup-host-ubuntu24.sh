#!/usr/bin/env bash
# Chuẩn bị Ubuntu Server 24.04 LTS để chạy redroid + Shadow Cloud Phone.
# Chạy bằng root:  sudo bash scripts/setup-host-ubuntu24.sh
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "Hãy chạy bằng sudo/root."; exit 1; }
. /etc/os-release
[ "${ID}" = "ubuntu" ] && [ "${VERSION_ID}" = "24.04" ] || echo "CẢNH BÁO: script được viết cho Ubuntu 24.04 (đang là ${PRETTY_NAME})."

echo "==> Cài Docker Engine (kho chính thức của Docker)"
apt-get update
apt-get install -y ca-certificates curl
install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
chmod a+r /etc/apt/keyrings/docker.asc
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu ${VERSION_CODENAME} stable" > /etc/apt/sources.list.d/docker.list
apt-get update
apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

echo "==> Nạp module binder cho redroid"
apt-get install -y "linux-modules-extra-$(uname -r)" || true
if ! modinfo binder_linux >/dev/null 2>&1; then
  echo "LỖI: kernel $(uname -r) không có module binder_linux."
  echo "Kernel của nhà cung cấp VPS (ví dụ -kvm, -aws) thường thiếu binder. Hãy dùng linux-generic hoặc máy vật lý/VM cho phép đổi kernel."
  exit 1
fi
modprobe binder_linux devices="binder,hwbinder,vndbinder"
echo binder_linux > /etc/modules-load.d/redroid.conf
echo 'options binder_linux devices=binder,hwbinder,vndbinder' > /etc/modprobe.d/redroid.conf
ls /dev/binderfs 2>/dev/null || true

echo "==> Kiểm tra nhanh"
lsmod | grep -q binder_linux && echo "binder_linux: OK" || { echo "binder_linux: CHƯA nạp"; exit 1; }

cat <<MSG

Xong phần máy chủ. Gợi ý tường lửa (tự kiểm tra trước khi bật):
  ufw allow OpenSSH && ufw allow 80,443/tcp
  # WebRTC trực tiếp cần UDP; nếu dùng TURN thì chỉ cần:
  ufw allow 3478/udp && ufw allow 49160:49200/udp
  # TUYỆT ĐỐI không mở cổng 5555 (ADB) hay 8000 (API) ra Internet.
Tiếp theo: cp .env.example .env && nano .env && docker compose up -d --build
MSG
