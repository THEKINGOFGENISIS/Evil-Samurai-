(function () {
  "use strict";
  const BASE = (window.SHADOW_API || "").replace(/\/$/, "");
  let token = null, tokenExp = 0, refreshing = null;
  const S = { user: null, lostHandlers: [] };

  S.esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  S.onAuthLost = fn => S.lostHandlers.push(fn);

  function setSession(d) {
    token = d.access_token;
    tokenExp = Date.now() + d.expires_in * 1000;
    S.user = d.user;
  }

  S.refresh = function () {
    if (!refreshing) {
      refreshing = fetch(BASE + "/api/auth/refresh", {
        method: "POST", credentials: "include", headers: { "X-Requested-With": "shadow" }
      }).then(async r => {
        if (!r.ok) throw new Error("no session");
        setSession(await r.json());
      }).finally(() => { refreshing = null; });
    }
    return refreshing;
  };

  S.login = async function (username, password) {
    const r = await fetch(BASE + "/api/auth/login", {
      method: "POST", credentials: "include", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password })
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.detail || "Đăng nhập thất bại");
    setSession(d);
  };

  S.register = async function (username, password) {
    const r = await fetch(BASE + "/api/auth/register", {
      method: "POST", credentials: "include", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password })
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(typeof d.detail === "string" ? d.detail : "Tên 3–32 ký tự (a-z, 0-9, _ . -) và mật khẩu ≥ 10 ký tự.");
  };

  S.logout = async function () {
    await fetch(BASE + "/api/auth/logout", { method: "POST", credentials: "include" }).catch(() => {});
    token = null; S.user = null;
  };

  async function send(path, opts, retry) {
    if (!token || Date.now() > tokenExp - 20000) { try { await S.refresh(); } catch (e) {} }
    const headers = { ...(opts.headers || {}) };
    if (token) headers.Authorization = "Bearer " + token;
    let body = opts.body;
    if (body !== undefined && typeof body !== "string") { body = JSON.stringify(body); headers["Content-Type"] = "application/json"; }
    const r = await fetch(BASE + path, { method: opts.method || "GET", headers, body, credentials: "include" });
    if (r.status === 401 && retry) {
      try { await S.refresh(); } catch (e) { S.lostHandlers.forEach(f => f()); throw new Error("Phiên đăng nhập đã hết hạn."); }
      return send(path, opts, false);
    }
    return r;
  }

  S.api = async function (path, opts = {}) {
    const r = await send(path, opts, true);
    const d = await r.json().catch(() => ({}));
    if (!r.ok) {
      const e = new Error(typeof d.detail === "string" ? d.detail : "Yêu cầu thất bại");
      e.status = r.status; throw e;
    }
    return d;
  };

  S.blob = async function (path) {
    const r = await send(path, {}, true);
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      const e = new Error(typeof d.detail === "string" ? d.detail : "Yêu cầu thất bại (HTTP " + r.status + ")");
      e.status = r.status; throw e;
    }
    return r.blob();
  };

  window.Shadow = S;
})();
