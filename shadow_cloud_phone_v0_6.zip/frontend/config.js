// Mặc định: giao diện và API cùng origin (Caddy/uvicorn phục vụ chung). Chỉ đổi khi chạy riêng, ví dụ:
// window.SHADOW_API = "https://api.example.com";
window.SHADOW_API = "";
