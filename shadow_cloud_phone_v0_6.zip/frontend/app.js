(function () {
  "use strict";
  const S = window.Shadow, $ = id => document.getElementById(id), esc = S.esc;
  let view = "devices", timer = null, loading = false;

  // ---------- đăng nhập ----------
  function showLogin() { $("login").classList.remove("hidden"); clearInterval(timer); setTimeout(() => $("lu").focus(), 50); }
  S.onAuthLost(showLogin);

  async function doLogin() {
    $("loginMsg").textContent = "Đang đăng nhập…";
    $("loginBtn").disabled = true;
    try {
      await S.login($("lu").value.trim(), $("lp").value);
      $("lp").value = ""; $("loginMsg").textContent = "";
      $("login").classList.add("hidden");
      start();
    } catch (e) { $("loginMsg").textContent = e.message; }
    $("loginBtn").disabled = false;
  }
  // ---------- tạo tài khoản ----------
  const show = (a, b) => { $(a).classList.remove("hidden"); $(b).classList.add("hidden"); };
  $("toReg").onclick = () => { show("regBox", "loginBox"); $("regMsg").textContent = ""; $("ru").focus(); };
  $("toLogin").onclick = () => show("loginBox", "regBox");
  fetch((window.SHADOW_API || "") + "/api/health").then(r => r.json())
    .then(h => { if (h.register === false) $("toReg").classList.add("hidden"); }).catch(() => {});
  async function doRegister() {
    const u = $("ru").value.trim(), p = $("rp").value;
    if (p !== $("rp2").value) { $("regMsg").textContent = "Mật khẩu nhập lại không khớp."; return; }
    $("regMsg").textContent = "Đang tạo tài khoản…";
    $("regBtn").disabled = true;
    try {
      await S.register(u, p);
      await S.login(u, p);
      $("rp").value = $("rp2").value = ""; $("regMsg").textContent = "";
      $("login").classList.add("hidden"); show("loginBox", "regBox");
      start();
    } catch (e) { $("regMsg").textContent = e.message; }
    $("regBtn").disabled = false;
  }
  $("regBtn").onclick = doRegister;
  $("rp2").onkeydown = e => { if (e.key === "Enter") doRegister(); };

  $("loginBtn").onclick = doLogin;
  $("lp").onkeydown = e => { if (e.key === "Enter") doLogin(); };
  $("lu").onkeydown = e => { if (e.key === "Enter") $("lp").focus(); };
  $("logout").onclick = async () => { await S.logout(); showLogin(); };

  // ---------- thiết bị ----------
  const thumbs = {}, thumbBusy = new Set();
  let menuId = null, filter = "all";

  function card(d) {
    const running = d.status === "running";
    let st = running ? (d.ready ? "running" : "booting") : d.status;
    if (d.mock) st = "mock · không có Android thật";
    const cls = running ? (d.ready ? "" : "booting") : "stopped";
    const link = d.ready ? 'href="device.html?id=' + esc(d.id) + '" target="_blank" rel="noopener"' : "";
    const t = thumbs[d.id], img = t && t.url ? `<img src="${t.url}" alt="">`
      : t && t.err ? `<span class="ph err">${esc(t.err)}</span>` : '<span class="ph">▯</span>';
    const label = d.platform_label ? `${esc(d.platform_label)} · Android ${esc(d.android)}` : esc(d.image);
    const tag = d.ready ? "a" : "div";
    const open = d.ready ? `<a class="btn open" ${link}>▶　Open Device</a>`
      : `<button class="open" disabled>${running ? "Đang khởi động Android…" : "Hãy Start để mở thiết bị"}</button>`;
    return `<article class="device ${d.ready ? "on" : ""}" data-id="${esc(d.id)}">
      <${tag} class="thumb" ${link}><span class="shotbox">${img}</span><span class="status ${cls}">● ${esc(st)}</span></${tag}>
      <div class="dinfo"><span class="avatar">${esc((d.name || "?").charAt(0).toUpperCase())}</span>
        <div class="dtext"><h3>${esc(d.name)}</h3><small>${label}</small>${d.error && !(d.ready && !d.mock) ? `<small class="derr">${esc(d.error)}</small>` : ""}</div>
        <button class="ico gear" data-menu title="Tùy chọn">⚙</button></div>
      <div class="actions ${menuId === d.id ? "show" : ""}">${open}
        <button data-act="start">Start</button><button class="secondary" data-act="restart">Restart</button>
        <button class="secondary" data-act="stop">Stop</button><button class="secondary" data-act="diag">Chẩn đoán</button><button class="danger" data-act="delete">Delete</button></div></article>`;
  }

  // ảnh chụp màn hình làm hình xem trước (làm mới tối đa 30 giây/lần)
  function loadThumbs(list) {
    list.filter(d => d.ready).forEach(async d => {
      const t = thumbs[d.id];
      if ((t && Date.now() - t.ts < 30000) || thumbBusy.has(d.id)) return;
      thumbBusy.add(d.id);
      let url = null, err = null;
      try { url = URL.createObjectURL(await S.blob(`/api/devices/${d.id}/screenshot`)); } catch (e) { err = e.message || "Không chụp được màn hình"; }
      if (t && t.url && url) URL.revokeObjectURL(t.url);
      thumbs[d.id] = { url: url || (t && t.url) || null, err: url ? null : err, ts: Date.now() };
      thumbBusy.delete(d.id);
      const boxes = document.querySelectorAll(`.device[data-id="${d.id}"] .shotbox`);
      if (thumbs[d.id].url) boxes.forEach(el => { el.innerHTML = `<img src="${thumbs[d.id].url}" alt="">`; });
      else if (err) boxes.forEach(el => { el.innerHTML = `<span class="ph err">${esc(err)}</span>`; });
    });
  }

  function pager() {
    const el = $("devices"), cards = el.querySelectorAll(".device"), n = cards.length;
    if (!n) { $("pager").textContent = ""; return; }
    const w = cards[0].offsetWidth + 14;
    $("pager").textContent = Math.min(n, Math.round(el.scrollLeft / w) + 1) + "/" + n;
  }
  $("devices").addEventListener("scroll", pager, { passive: true });

  async function load() {
    if (loading || document.hidden || view !== "devices") return;
    loading = true;
    try {
      const [list, health] = await Promise.all([S.api("/api/devices"),
        S.api("/api/status").catch(() => S.api("/api/health").catch(() => ({})))]);
      $("api").textContent = health.mock ? "MOCK" : health.docker ? "ONLINE" : "DOCKER OFF";
      $("adbChip").textContent = health.mock ? "MOCK" : health.adb === undefined ? "—" : health.adb ? "OK" : "LỖI";
      $("adbChip").title = health.adb_detail || "";
      const bn = $("banner");
      bn.textContent = (health.problems || []).join("  ·  ");
      bn.classList.toggle("hidden", !(health.problems || []).length);
      $("total").textContent = list.length;
      // chỉ tính là "đang chạy" khi Android đã boot xong và ADB trả lời thật
      $("running").textContent = list.filter(x => x.status === "running" && x.ready).length;
      const shown = list.filter(x => filter === "all" || (filter === "running" ? x.status === "running" : x.status !== "running"));
      const el = $("devices"), sl = el.scrollLeft;
      el.innerHTML = shown.length ? shown.map(card).join("")
        : `<div class="empty">${list.length ? "Không có thiết bị khớp bộ lọc." : "Chưa có Cloud Phone. Nhấn “Tạo máy” để bắt đầu."}</div>`;
      el.scrollLeft = sl; pager(); loadThumbs(list);
    } catch (e) {
      if (!$("login").classList.contains("hidden")) { loading = false; return; }
      $("api").textContent = "OFFLINE";
      $("devices").innerHTML = `<div class="empty">Không kết nối được API: ${esc(e.message)}<br>Hãy khởi động backend rồi tải lại trang.</div>`;
    }
    loading = false;
  }

  $("devices").onclick = async e => {
    const gear = e.target.closest("[data-menu]");
    if (gear) {
      const card = gear.closest(".device"), id = card.dataset.id;
      menuId = menuId === id ? null : id;
      card.querySelector(".actions").classList.toggle("show", menuId === id);
      return;
    }
    const btn = e.target.closest("button[data-act]");
    if (!btn) return;
    const id = btn.closest(".device").dataset.id, act = btn.dataset.act;
    if (act === "diag") return runDiag(id);
    try {
      if (act === "delete") {
        if (!confirm("Xóa thiết bị này? Dữ liệu Android của thiết bị cũng sẽ bị xóa.")) return;
        await S.api(`/api/devices/${id}`, { method: "DELETE" });
      } else {
        btn.disabled = true;
        await S.api(`/api/devices/${id}/${act}`, { method: "POST" });
      }
      load();
    } catch (err) { alert(err.message); load(); }
  };

  // ---------- chẩn đoán thật ----------
  $("diagClose").onclick = () => $("diagModal").classList.add("hidden");
  async function runDiag(id) {
    $("diagModal").classList.remove("hidden");
    $("diagSummary").textContent = "Đang kiểm tra Docker, ADB, ảnh màn hình, luồng H.264 và cảm ứng… (có thể mất vài giây)";
    $("diagRows").innerHTML = "";
    try {
      const r = await S.api(`/api/devices/${id}/diagnostics`);
      $("diagSummary").textContent = r.summary;
      $("diagRows").innerHTML = r.steps.map(x => {
        const c = x.ok === true ? "ok" : x.ok === false ? "bad" : "skip", ic = x.ok === true ? "✔" : x.ok === false ? "✖" : "–";
        return `<div class="row ${c}"><i>${ic}</i><div><b>${esc(x.label)}</b><span>${esc(x.detail)}${x.ms ? " · " + x.ms + " ms" : ""}</span></div></div>`;
      }).join("");
      const sc = r.stream && r.stream.source;
      if (sc) $("diagRows").innerHTML += `<div class="row ${sc.state === "live" ? "ok" : sc.state === "error" ? "bad" : "skip"}"><i>${sc.state === "live" ? "✔" : sc.state === "error" ? "✖" : "–"}</i><div><b>Luồng WebRTC đang chạy</b><span>${esc(sc.state)}${sc.error ? " — " + esc(sc.error) : ""} · ${sc.frames} khung hình · ${r.stream.sessions} người xem</span></div></div>`;
    } catch (e) { $("diagSummary").textContent = "Không chẩn đoán được: " + e.message; }
  }

  $("add").onclick = async () => {
    $("modal").classList.remove("hidden"); $("message").textContent = "";
    try {
      const ps = await S.api("/api/platforms");
      $("devicePlatform").innerHTML = ps.map(p =>
        `<option value="${esc(p.key)}"${p.default ? " selected" : ""}>${esc(p.label)} · Android ${esc(p.android)}</option>`).join("");
    } catch (e) { $("message").textContent = e.message; }
  };
  $("filter").onchange = e => { filter = e.target.value; load(); };
  $("refreshBtn").onclick = () => load();
  $("close").onclick = () => $("modal").classList.add("hidden");
  $("confirm").onclick = async () => {
    $("message").textContent = "Đang tạo…";
    try {
      await S.api("/api/devices", { method: "POST", body: { name: $("deviceName").value, platform: $("devicePlatform").value || undefined } });
      $("modal").classList.add("hidden"); $("message").textContent = ""; load();
    } catch (e) { $("message").textContent = e.message; }
  };

  // ---------- lịch sử ----------
  const fmt = t => new Date(t * 1000).toLocaleString("vi-VN");
  async function loadHistory() {
    const rows = await S.api("/api/audit?limit=100");
    $("auditRows").innerHTML = rows.length ? rows.map(r =>
      `<tr><td>${esc(fmt(r.ts))}</td><td>${esc(r.user || "")}</td><td>${esc(r.action)}</td><td>${esc(r.target || "")}</td><td>${esc(r.ip || "")}</td></tr>`).join("")
      : '<tr><td colspan="5" class="muted">Chưa có hoạt động.</td></tr>';
  }

  // ---------- cài đặt ----------
  $("pwBtn").onclick = async () => {
    $("pwMsg").style.color = "#ff9b9b";
    try {
      await S.api("/api/auth/password", { method: "POST", body: { current: $("pwCur").value, new: $("pwNew").value } });
      $("pwCur").value = $("pwNew").value = ""; $("pwMsg").style.color = "var(--ok)"; $("pwMsg").textContent = "Đã đổi mật khẩu.";
    } catch (e) { $("pwMsg").textContent = e.message.includes("[") ? "Mật khẩu mới phải có ít nhất 10 ký tự." : e.message; }
  };
  async function loadUsers() {
    const users = await S.api("/api/users");
    $("userRows").innerHTML = users.map(u => `<tr><td>${esc(u.username)}</td><td>${esc(u.role)}</td>
      <td>${u.id === S.user.id ? "" : `<button class="danger" style="padding:6px 10px;font-size:12px" data-del="${u.id}">Xóa</button>`}</td></tr>`).join("");
  }
  $("userRows").onclick = async e => {
    const id = e.target.dataset.del;
    if (!id || !confirm("Xóa người dùng này?")) return;
    try { await S.api(`/api/users/${id}`, { method: "DELETE" }); loadUsers(); } catch (err) { alert(err.message); }
  };
  $("nuBtn").onclick = async () => {
    $("nuMsg").textContent = "";
    try {
      await S.api("/api/users", { method: "POST", body: { username: $("nuName").value.trim(), password: $("nuPass").value, role: $("nuRole").value } });
      $("nuName").value = $("nuPass").value = ""; loadUsers();
    } catch (e) { $("nuMsg").textContent = e.message.includes("[") ? "Tên 3–32 ký tự (a-z, 0-9, _ . -) và mật khẩu ≥ 10 ký tự." : e.message; }
  };

  // ---------- điều hướng ----------
  const TITLES = { devices: ["Thiết bị của tôi", "Quản lý Android Cloud từ trình duyệt"], history: ["Lịch sử", "Nhật ký hoạt động gần đây"], settings: ["Cài đặt", "Tài khoản và người dùng"] };
  function go(v) {
    view = v;
    ["devices", "history", "settings"].forEach(n => $("v-" + n).classList.toggle("hidden", n !== v));
    document.querySelectorAll("[data-view]").forEach(b => b.classList.toggle("active", b.dataset.view === v));
    $("title").textContent = TITLES[v][0]; $("subtitle").textContent = TITLES[v][1];
    if (v === "devices") load();
    if (v === "history") loadHistory().catch(e => alert(e.message));
    if (v === "settings" && S.user.role === "admin") loadUsers().catch(() => {});
  }
  document.querySelectorAll("[data-view]").forEach(b => b.onclick = () => go(b.dataset.view));

  function start() {
    $("me").textContent = S.user.username;
    $("adminCard").classList.toggle("hidden", S.user.role !== "admin");
    go("devices");
    clearInterval(timer);
    timer = setInterval(load, 5000);
  }
  document.addEventListener("visibilitychange", () => { if (!document.hidden) load(); });

  // ---------- khởi động: thử dùng phiên cũ (cookie refresh) ----------
  S.refresh().then(start).catch(showLogin);
})();
