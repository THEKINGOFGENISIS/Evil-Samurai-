(function () {
  "use strict";
  const S = window.Shadow, $ = id => document.getElementById(id);
  const id = new URLSearchParams(location.search).get("id") || "";
  if (!/^[a-f0-9]{6,64}$/.test(id)) { location.replace("index.html"); return; }
  S.onAuthLost(() => location.replace("index.html"));

  const video = $("video"), screen = $("screen"), kb = $("kb");
  let pc = null, dc = null, session = null, attempt = 0, retryTimer = null, connecting = false;
  let quality = "medium", lastFrames = -1, stallSince = 0, lastBytes = 0, lastT = 0, pingRtt = null;
  let streamErr = false, connectedAt = 0, gotVideo = false;
  try { quality = localStorage.getItem("shadow.quality") || "medium"; } catch (e) {}
  if (!["low", "medium", "high"].includes(quality)) quality = "medium";
  $("quality").value = quality;

  // ---------- trạng thái giao diện ----------
  function overlay(text, spin = true) {
    $("overlay").classList.remove("hidden");
    $("overlayText").textContent = text;
    $("overlay").querySelector(".spinner").classList.toggle("hidden", !spin);
  }
  function state(text, cls) {
    $("stState").textContent = text;
    $("dot").className = "dot " + (cls || "");
  }
  function schedule(ms) { clearTimeout(retryTimer); retryTimer = setTimeout(connect, ms); }
  function backoff() { const ms = Math.min(1000 * 2 ** attempt, 15000); attempt++; return ms; }

  function teardown() {
    clearTimeout(retryTimer);
    if (dc) { dc.onopen = dc.onmessage = dc.onclose = null; try { dc.close(); } catch (e) {} dc = null; }
    if (pc) { pc.onconnectionstatechange = pc.ontrack = null; try { pc.close(); } catch (e) {} pc = null; }
    lastFrames = -1; stallSince = 0; lastBytes = 0; pingRtt = null; streamErr = false; gotVideo = false; connectedAt = 0;
  }

  function waitIce(conn, ms) {
    return new Promise(res => {
      if (conn.iceGatheringState === "complete") return res();
      const done = () => { clearTimeout(t); conn.removeEventListener("icegatheringstatechange", chk); res(); };
      const chk = () => { if (conn.iceGatheringState === "complete") done(); };
      const t = setTimeout(done, ms);
      conn.addEventListener("icegatheringstatechange", chk);
    });
  }

  // ---------- kết nối WebRTC (tự kết nối lại) ----------
  async function connect() {
    if (connecting) return;
    connecting = true;
    teardown();
    state("Đang kết nối…", "");
    try {
      const d = await S.api(`/api/devices/${id}`);
      $("devName").textContent = d.name;
      document.title = d.name + " · Shadow Cloud";
      if (d.status !== "running") { overlay("Thiết bị đang dừng. Hãy nhấn Start ở trang Thiết bị.", false); state("Đã dừng", "bad"); connecting = false; return schedule(5000); }
      if (!d.ready) { overlay("Android đang khởi động, vui lòng đợi…"); state("Đang boot", ""); connecting = false; return schedule(3000); }

      overlay(attempt ? "Đang kết nối lại…" : "Đang kết nối…");
      const cfg = await S.api("/api/webrtc/ice");
      const conn = new RTCPeerConnection({ iceServers: cfg.iceServers, iceTransportPolicy: cfg.iceTransportPolicy });
      pc = conn;
      conn.addTransceiver("video", { direction: "recvonly" });
      const ch = conn.createDataChannel("control", { ordered: true });
      dc = ch;
      ch.onopen = () => { ping(); };
      ch.onmessage = ev => {
        let m; try { m = JSON.parse(ev.data); } catch (e) { return; }
        if (m.t === "pong") {
          pingRtt = Math.round(performance.now() - m.ts);
          // trạng thái THẬT của luồng hình do backend báo (không còn khung hình giả)
          if (m.s === "error" && m.e) {
            streamErr = true; state("Lỗi luồng hình", "bad");
            overlay("Android không trả về hình ảnh:\n" + m.e + "\n\nNhấn “Xem thêm → Chẩn đoán” để xem chi tiết.", false);
          } else if (m.s === "live" && streamErr) { streamErr = false; if (gotVideo) $("overlay").classList.add("hidden"); }
          if (m.i) $("note").textContent = m.i;
        }
        if (m.t === "warn") $("note").textContent = m.m;
      };
      conn.ontrack = ev => {
        video.srcObject = ev.streams[0] || new MediaStream([ev.track]);
        video.play().catch(() => {});
      };
      conn.onconnectionstatechange = () => {
        if (pc !== conn) return;
        const s = conn.connectionState;
        if (s === "connected") { attempt = 0; connectedAt = performance.now(); if (!gotVideo) state("Đã kết nối WebRTC — chờ hình từ Android", ""); }
        else if (s === "disconnected") { state("Mất tín hiệu…", ""); overlay("Mất kết nối, đang thử lại…"); schedule(4000); }
        else if (s === "failed" || s === "closed") { state("Mất kết nối", "bad"); overlay("Kết nối bị ngắt, đang kết nối lại…"); schedule(backoff()); }
      };

      await conn.setLocalDescription(await conn.createOffer());
      await waitIce(conn, 3000);
      const ans = await S.api(`/api/devices/${id}/webrtc/offer`, {
        method: "POST",
        body: { sdp: conn.localDescription.sdp, type: "offer", quality, ...(session ? { replace: session } : {}) }
      });
      if (pc !== conn) { connecting = false; return; }
      session = ans.session;
      $("note").textContent = ans.input_mode === "input" ? "Chế độ cảm ứng dự phòng: vuốt được thực hiện khi nhả tay." : "";
      await conn.setRemoteDescription({ type: ans.type, sdp: ans.sdp });
    } catch (e) {
      if (e.status === 409) { overlay(e.message); connecting = false; return schedule(3000); }
      if (e.status === 429) { overlay(e.message); connecting = false; return schedule(5000); }
      state("Lỗi", "bad"); overlay((e.message || "Không kết nối được") + " — đang thử lại…");
      schedule(backoff());
    }
    connecting = false;
  }

  video.addEventListener("playing", () => { gotVideo = true; streamErr = false; $("overlay").classList.add("hidden"); state("Đang phát trực tiếp", "live"); });
  video.addEventListener("resize", () => {
    if (video.videoWidth && video.videoHeight) screen.style.aspectRatio = video.videoWidth + " / " + video.videoHeight;
  });

  // tự kết nối lại khi quay lại tab / có mạng trở lại
  const healthy = () => pc && pc.connectionState === "connected";
  document.addEventListener("visibilitychange", () => { if (!document.hidden && !healthy()) { attempt = 0; connect(); } });
  window.addEventListener("online", () => { if (!healthy()) { attempt = 0; connect(); } });
  window.addEventListener("pagehide", () => { if (pc) pc.close(); });

  // ---------- gửi điều khiển qua DataChannel ----------
  function send(o) { if (dc && dc.readyState === "open") dc.send(JSON.stringify(o)); }
  function ping() { send({ t: "ping", ts: performance.now() }); }

  // ---------- cảm ứng / chuột (đa điểm) ----------
  const slots = new Map(), lastPos = new Map(), lastSent = new Map();
  const clamp = v => Math.min(1, Math.max(0, v));
  function norm(e) {
    const r = video.getBoundingClientRect(), vw = video.videoWidth || 9, vh = video.videoHeight || 16;
    const sc = Math.min(r.width / vw, r.height / vh), w = vw * sc, h = vh * sc;
    return { x: clamp((e.clientX - (r.left + (r.width - w) / 2)) / w), y: clamp((e.clientY - (r.top + (r.height - h) / 2)) / h) };
  }
  function slotFor(pid) {
    if (slots.has(pid)) return slots.get(pid);
    const used = new Set(slots.values());
    for (let i = 0; i < 5; i++) if (!used.has(i)) { slots.set(pid, i); return i; }
    return -1;
  }
  screen.addEventListener("pointerdown", e => {
    if (e.pointerType === "mouse" && e.button !== 0) return;
    const s = slotFor(e.pointerId); if (s < 0) return;
    try { screen.setPointerCapture(e.pointerId); } catch (x) {}
    const p = norm(e); lastPos.set(e.pointerId, p); lastSent.set(e.pointerId, performance.now());
    send({ t: "touch", a: "down", id: s, ...p });
    if (e.pointerType === "mouse") kb.focus({ preventScroll: true });
    $("panel").classList.remove("open");
    e.preventDefault();
  });
  screen.addEventListener("pointermove", e => {
    if (!slots.has(e.pointerId)) return;
    const p = norm(e); lastPos.set(e.pointerId, p);
    const now = performance.now();
    if (now - lastSent.get(e.pointerId) < 8) return;
    lastSent.set(e.pointerId, now);
    send({ t: "touch", a: "move", id: slots.get(e.pointerId), ...p });
    e.preventDefault();
  });
  function release(e, cancel) {
    const s = slots.get(e.pointerId); if (s === undefined) return;
    const p = cancel ? lastPos.get(e.pointerId) : norm(e);
    if (!cancel) send({ t: "touch", a: "move", id: s, ...p });   // vị trí cuối chính xác trước khi nhả
    send({ t: "touch", a: cancel ? "cancel" : "up", id: s, ...p });
    slots.delete(e.pointerId); lastPos.delete(e.pointerId); lastSent.delete(e.pointerId);
  }
  screen.addEventListener("pointerup", e => release(e, false));
  screen.addEventListener("pointercancel", e => release(e, true));
  screen.addEventListener("lostpointercapture", e => release(e, true));
  screen.addEventListener("contextmenu", e => e.preventDefault());
  screen.addEventListener("wheel", e => {
    e.preventDefault();
    const p = norm(e); send({ t: "scroll", x: p.x, y: p.y, dy: e.deltaY });
  }, { passive: false });

  // ---------- bàn phím ----------
  const KEYS = { Backspace: "BACKSPACE", Delete: "DELETE", Enter: "ENTER", Tab: "TAB", Escape: "BACK",
    ArrowUp: "UP", ArrowDown: "DOWN", ArrowLeft: "LEFT", ArrowRight: "RIGHT",
    Home: "MOVE_HOME", End: "MOVE_END", PageUp: "PAGE_UP", PageDown: "PAGE_DOWN" };
  kb.addEventListener("keydown", e => {
    if (e.isComposing || e.ctrlKey || e.metaKey || e.altKey) return;
    const k = KEYS[e.key];
    if (k) { send({ t: "key", k }); e.preventDefault(); }
  });
  document.addEventListener("keydown", e => {
    if (document.activeElement === kb || e.ctrlKey || e.metaKey || e.altKey) return;
    if (/^(INPUT|SELECT|TEXTAREA)$/.test(e.target.tagName)) return;
    const k = KEYS[e.key];
    if (k) { send({ t: "key", k }); e.preventDefault(); }
    else if (e.key.length === 1) kb.focus({ preventScroll: true });   // ký tự in được sẽ vào ô nhập ẩn rồi gửi sang Android
  });
  kb.addEventListener("beforeinput", e => {
    if (e.isComposing) return;                         // văn bản đang soạn: gửi khi compositionend
    const t = e.inputType;
    if (t === "insertText" && e.data) send({ t: "text", s: e.data });
    else if (t === "insertFromPaste") { const s = e.dataTransfer ? e.dataTransfer.getData("text/plain") : e.data; if (s) send({ t: "text", s }); }
    else if (t === "deleteContentBackward") send({ t: "key", k: "BACKSPACE" });
    else if (t === "deleteContentForward") send({ t: "key", k: "DELETE" });
    else if (t === "insertLineBreak" || t === "insertParagraph") send({ t: "key", k: "ENTER" });
    e.preventDefault();
  });
  kb.addEventListener("compositionend", e => { if (e.data) send({ t: "text", s: e.data }); kb.value = ""; });
  $("kbBtn").onclick = () => { kb.focus(); $("panel").classList.remove("open"); };

  // ---------- nút điều khiển ----------
  document.addEventListener("click", e => {
    const b = e.target.closest("[data-key]");
    if (b) { send({ t: "key", k: b.dataset.key }); if (b.closest("#panel")) $("panel").classList.remove("open"); }
  });
  $("diagBtn").onclick = async () => {
    const out = $("diagOut"); out.classList.remove("hidden"); out.textContent = "Đang chẩn đoán… (vài giây)";
    try {
      const r = await S.api(`/api/devices/${id}/diagnostics`);
      let t = r.summary + "\n";
      r.steps.forEach(x => { t += "\n" + (x.ok === true ? "✔ " : x.ok === false ? "✖ " : "– ") + x.label + ": " + x.detail; });
      const sc = r.stream && r.stream.source;
      if (sc) t += "\n\nLuồng WebRTC: " + sc.state + (sc.error ? " — " + sc.error : "") + " · " + sc.frames + " khung hình";
      out.textContent = t;
    } catch (e) { out.textContent = "Không chẩn đoán được: " + e.message; }
  };
  $("panelToggle").onclick = () => $("panel").classList.toggle("open");
  $("reBtn").onclick = () => { attempt = 0; connect(); };
  $("quality").onchange = e => {
    quality = e.target.value;
    try { localStorage.setItem("shadow.quality", quality); } catch (x) {}
    send({ t: "quality", q: quality });
  };
  if (!document.fullscreenEnabled) $("fsBtn").classList.add("hidden");
  $("fsBtn").onclick = () => { document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen().catch(() => {}); };
  $("shotBtn").onclick = async () => {
    try {
      const url = URL.createObjectURL(await S.blob(`/api/devices/${id}/screenshot`));
      const a = document.createElement("a"); a.href = url; a.download = "screenshot-" + Date.now() + ".png";
      document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 5000);
    } catch (e) { $("note").textContent = e.message; }
  };

  // ---------- thống kê + phát hiện treo hình ----------
  async function stats() {
    ping();
    if (!pc || pc.connectionState !== "connected") return;
    let rep; try { rep = await pc.getStats(); } catch (e) { return; }
    let inbound = null, pair = null;
    rep.forEach(r => {
      if (r.type === "inbound-rtp" && (r.kind === "video" || r.mediaType === "video")) inbound = r;
      if (r.type === "transport" && r.selectedCandidatePairId) pair = rep.get(r.selectedCandidatePairId);
    });
    if (!pair) rep.forEach(r => { if (r.type === "candidate-pair" && r.state === "succeeded" && (r.nominated || !pair)) pair = r; });
    if (inbound) {
      const now = performance.now();
      if (lastT) $("stKbps").textContent = Math.round((inbound.bytesReceived - lastBytes) * 8 / ((now - lastT) / 1000) / 1000) + " kbps";
      lastBytes = inbound.bytesReceived; lastT = now;
      $("stFps").textContent = Math.round(inbound.framesPerSecond || 0) + " fps";
      if (inbound.frameWidth) $("stRes").textContent = inbound.frameWidth + "×" + inbound.frameHeight;
      // không có khung hình mới trong 8 giây dù đang "connected" => kết nối lại
      if (!inbound.framesDecoded && connectedAt && now - connectedAt > 25000 && !streamErr) {
        overlay("Đã kết nối WebRTC nhưng chưa nhận được hình nào từ Android sau 25 giây.\nNhấn “Xem thêm → Chẩn đoán” để biết nguyên nhân.", false);
      }
      if (!inbound.framesDecoded || streamErr) { stallSince = 0; }
      else if (inbound.framesDecoded === lastFrames) {
        if (!stallSince) stallSince = now;
        else if (now - stallSince > 8000) { stallSince = 0; attempt = 0; overlay("Hình ảnh bị treo, đang kết nối lại…"); connect(); return; }
      } else { stallSince = 0; lastFrames = inbound.framesDecoded; }
    }
    const rtt = pingRtt ?? (pair && pair.currentRoundTripTime != null ? Math.round(pair.currentRoundTripTime * 1000) : null);
    $("stRtt").textContent = rtt != null ? rtt + " ms" : "—";
    if (pair) {
      const lc = rep.get(pair.localCandidateId);
      const t = lc && lc.candidateType;
      $("stRoute").textContent = t === "relay" ? "TURN" : t === "host" ? "Trực tiếp" : t ? "P2P" : "—";
    }
  }
  setInterval(stats, 2000);

  connect();
})();
