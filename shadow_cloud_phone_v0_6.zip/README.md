# Shadow Cloud Phone — v0.5.0

Cloud Phone chạy **Android thật (redroid)** trên Ubuntu Server 24.04 LTS, điều khiển từ trình duyệt (máy tính và điện thoại) qua **WebRTC**.

## Đã có gì

| Nhóm | Nội dung |
|---|---|
| Giữ nguyên từ v0.1 | Tạo / Start / Stop / Restart / Delete thiết bị, thống kê, trạng thái API, `DEVICE_LIMIT`, container gắn nhãn `shadow-cloud-phone=true` |
| Open Device | Nút **Open Device** (chỉ bật khi Android đã boot xong) mở trang xem điện thoại thật |
| Hình ảnh | `adb screenrecord` (H.264) → giải mã → aiortc mã hóa lại → WebRTC (ưu tiên H.264, dự phòng VP8) |
| Điều khiển | Cảm ứng đa điểm, vuốt, cuộn chuột, phím Back/Home/Recents/âm lượng/nguồn, bàn phím, dán văn bản, chụp màn hình |
| Kết nối lại | Tự kết nối lại có lùi dần, khi quay lại tab, khi có mạng, khi hình ảnh bị treo 8 giây |
| Hiệu năng | Một nguồn quay cho nhiều người xem; tự dừng sau 20 giây không ai xem; màn hình tĩnh hạ xuống 5 fps; 3 mức chất lượng; gom lô sự kiện cảm ứng |
| Bảo mật | Đăng nhập, JWT ngắn hạn + refresh xoay vòng (cookie httpOnly), phân quyền theo chủ sở hữu, chống dò mật khẩu, giới hạn tốc độ, kiểm tra Origin, CSP, nhật ký hoạt động |
| Giao diện | Đen–đỏ, responsive: thanh tab dưới trên điện thoại, menu dạng bottom sheet trong trang xem |

## Kiến trúc

```
Trình duyệt ──HTTPS──> Caddy ──> API (FastAPI, 127.0.0.1:8000, network_mode: host)
     │                                  │  Docker socket → tạo/quản lý container redroid
     └──WebRTC (UDP / TURN)─────────────┤  ADB (mạng bridge nội bộ shadow-net, cổng 5555 KHÔNG publish)
                                        └─> redroid (Android 12)
```

## Cài đặt (Ubuntu Server 24.04 LTS)

```bash
sudo bash scripts/setup-host-ubuntu24.sh     # Docker + module binder_linux
cp .env.example .env && nano .env            # đặt ADMIN_PASSWORD, SITE_ADDRESS...
docker compose up -d --build
docker compose logs api | head -20           # nếu để trống ADMIN_PASSWORD, mật khẩu sinh ra nằm ở đây
```

Mở `http://IP-MÁY-CHỦ` (hoặc tên miền), đăng nhập, bấm **Tạo Cloud Phone**, đợi trạng thái chuyển từ `booting` sang `running`, rồi bấm **Open Device**.

- **HTTPS**: đặt `SITE_ADDRESS=phone.example.com` và `COOKIE_SECURE=1`; Caddy tự lấy chứng chỉ. Cần mở cổng 80/443.
- **Mạng di động / NAT chặt**: bật TURN — đặt `TURN_SECRET`, `PUBLIC_IP`, `TURN_URLS=turn:phone.example.com:3478`, chạy `docker compose --profile turn up -d`, mở UDP `3478` và `49160-49200`.
- **Gõ tiếng Việt / Unicode**: `input text` của Android chỉ nhận ASCII. Đặt `ADBKeyboard.apk` vào thư mục `apks/`; hệ thống tự cài và bật ở lần boot đầu tiên (các APK khác trong `apks/` cũng được cài tự động).
- **Tài liệu API**: đặt `ENABLE_DOCS=1` để bật `/docs`.

## Điều kiện bắt buộc về máy chủ

redroid cần kernel có `binder_linux`. Nhiều VPS dùng kernel riêng (`-kvm`, `-aws`…) **không có** module này; khi đó script cài đặt sẽ báo lỗi và thiết bị sẽ không boot. Hãy dùng máy vật lý hoặc VM cho phép dùng kernel `linux-generic`. Image mặc định đã đổi sang `redroid/redroid:12.0.0-latest` (tag theo tài liệu redroid); container tạo với `androidboot.use_memfd=true` vì kernel 24.04 không có ashmem.

## Bảo mật — cần biết

- API giữ **Docker socket** nên nếu API bị chiếm quyền thì máy chủ cũng bị chiếm. Vì vậy API chỉ lắng nghe `127.0.0.1`, chạy `read_only`, `cap_drop: ALL`, và chỉ cho phép cấu hình container cố định (người dùng chỉ đặt được tên). Không bao giờ publish cổng 8000, 5555 hay Docker socket ra Internet.
- Thiết bị redroid chạy `privileged` (bắt buộc với redroid). Xem chúng là không đáng tin cậy với mạng nội bộ của bạn; cân nhắc chặn container đi tới mạng LAN bằng iptables.
- Đăng nhập sai 5 lần bị khóa 5 phút theo IP+tài khoản; refresh token bị dùng lại sẽ thu hồi toàn bộ phiên.
- Giới hạn mặc định: 1 thiết bị mỗi người dùng thường, tối đa 2 người xem mỗi thiết bị.

## Giới hạn đã biết

- Chưa có âm thanh (`screenrecord` không ghi âm).
- Chưa hỗ trợ xoay ngang; màn hình cố định dọc 720×1280 (đổi bằng `ANDROID_WIDTH/HEIGHT`).
- `screenrecord` giới hạn 180 giây/lần nên luồng hình khởi động lại mỗi ~3 phút (gián đoạn rất ngắn).
- Hình ảnh được giải mã rồi mã hóa lại bằng CPU (không dùng GPU) nên tốn CPU theo số người xem; hãy bắt đầu với 1 thiết bị.
- Chế độ cảm ứng nhanh dùng `sendevent` vào thiết bị input do redroid tạo; nếu không dò được, hệ thống tự chuyển sang `input tap/swipe` (vuốt chỉ thực hiện khi nhả tay).

## Kiểm thử

```bash
cd backend && python3 -m unittest discover -s tests -v   # logic cảm ứng, TURN, xác thực, xoay vòng token
```

## Cấu trúc

- `backend/` — `main.py` (API), `auth.py`, `devices.py` (Docker/redroid), `adb.py`, `inputs.py` (cảm ứng/phím), `stream.py` (WebRTC), `ice.py`
- `frontend/` — `index.html` + `app.js` (dashboard), `device.html` + `device.js` (Open Device), `common.js`, `style.css`
- `caddy/Caddyfile`, `docker-compose.yml`, `scripts/setup-host-ubuntu24.sh`, `apks/`

## Thay đổi v0.3 → v0.5

- **Tạo tài khoản** ngay ở màn hình đăng nhập (bật bằng `ALLOW_REGISTER=1`, mặc định tắt).
- **Chọn loại thiết bị** khi tạo máy: Typhoon (Android 13), Universe (14), Voyager (15). Thêm loại mới bằng 1 dòng trong `PLATFORMS` ở `backend/config.py`; đổi image bằng `IMAGE_TYPHOON/UNIVERSE/VOYAGER`. Máy chủ ARM dùng bản `_64only`.
- **Giao diện kiểu app**: danh sách máy dạng thẻ vuốt ngang có ảnh xem trước (chụp màn hình, làm mới ≤30 giây), bộ lọc, nút ⚙ cho Start/Restart/Stop/Delete. Trang Open Device nền đen, thanh công cụ dọc bên phải (toàn màn hình, âm lượng, chụp màn hình, bàn phím, nguồn), chọn chất lượng và hiện độ trễ ở trên.
- Chưa có: Tải lên, Sửa GPS, Cửa sổ nổi, thời gian thuê máy (cần thêm backend).
- `mock_server.py` chạy thử giao diện không cần Docker (`python mock_server.py`).

## Thay đổi v0.5 → v0.6 (trạng thái thật, không giả lập)

Giữ nguyên toàn bộ giao diện và chức năng cũ; chỉ thêm kiểm tra thật và báo lỗi chính xác.

- **`running` chỉ khi Android thật sự chạy**: ô "Đang chạy" ở Dashboard đếm máy có container chạy **và** `sys.boot_completed=1` qua ADB. Máy đang boot hoặc ADB lỗi hiện đúng lý do ngay trên thẻ (ví dụ `failed to connect to …:5555`, container thoát mã 1, OOM…).
- **`GET /api/status`** (cần đăng nhập): Docker, chương trình `adb`, thư viện WebRTC (aiortc/PyAV, có bộ mã hóa H.264/VP8 không). Dashboard có thêm chip **ADB** và banner đỏ khi có vấn đề.
- **`GET /api/devices/{id}/diagnostics`** và nút **Chẩn đoán** (thẻ thiết bị + trang Open Device → Xem thêm): kiểm tra lần lượt Docker → container → mạng → kết nối ADB → boot → kích thước màn hình → `screencap` (PNG thật, đọc kích thước từ header) → `screenrecord` H.264 (chạy 2 giây, kiểm tra có NAL H.264) → thiết bị cảm ứng → ADBKeyboard. Bước nào lỗi thì các bước sau ghi "bỏ qua", không bao giờ báo thành công giả.
- **Ảnh màn hình**: lỗi `screencap` được trả về nguyên văn (HTTP 409/503 kèm nguyên nhân) và hiện trên thẻ thay vì bị nuốt.
- **WebRTC không còn khung hình xám giả**: khi `screenrecord` chưa ra hình, track chờ hình thật. Trạng thái luồng (`starting/live/error` + lỗi stderr của `screenrecord`) được gửi qua DataChannel (`pong`) và trình xem hiển thị đúng lỗi; chỉ báo "Đang phát trực tiếp" khi trình duyệt thực sự nhận được khung hình. Lỗi ghi lệnh điều khiển vào Android cũng hiện ở ghi chú.
- **Bàn phím vật lý** gõ được ngay (không cần bấm vào màn hình trước); phím đặc biệt (Backspace, Enter, mũi tên…) gửi thẳng.
- `mock_server.py` vẫn dùng để thử giao diện nhưng nay ghi rõ **MOCK** ở mọi nơi (chip API/ADB, trạng thái thẻ, chẩn đoán trả về lỗi "không có Android thật").
- Thêm 7 test (`AdbDiagnose`) dùng `tests/fake_adb.py` mô phỏng các lỗi: mất kết nối, đang boot, `screencap` lỗi, `screenrecord` lỗi, thiếu `adb`.
