#!/usr/bin/env python3
"""Mock server để TEST GIAO DIỆN Shadow Cloud Phone mà không cần Docker/redroid/Ubuntu.

Chạy:   python mock_server.py            (mở http://127.0.0.1:8080)
Đăng nhập: admin / admin12345
Chỉ dùng thư viện chuẩn của Python 3.8+ (Windows/Mac/Linux đều chạy được).
Thiết bị là GIẢ (giao diện ghi rõ "mock"): Create/Start/Stop/Restart/Delete, booting -> running sau vài giây.
Open Device chưa có hình thật (cần backend thật + redroid).
"""
import json
import mimetypes
import re
import secrets
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

PORT = 8080
BOOT_SECONDS = 6
FRONT = Path(__file__).parent / "frontend"
COOKIE = "shadow_refresh"

USERS = {1: {"id": 1, "username": "admin", "role": "admin", "disabled": False, "created_at": int(time.time()), "pw": "admin12345"}}
NEXT_UID = [2]
DEVICES = {}      # id -> dict
AUDIT = []        # newest first
SESSIONS = {}     # refresh token -> user id


def audit(user, action, target="", ip="127.0.0.1"):
    AUDIT.insert(0, {"id": len(AUDIT) + 1, "ts": int(time.time()), "user": user, "action": action, "target": target, "ip": ip})


PLAT = {"typhoon": ("Typhoon", "13", "redroid/redroid:13.0.0-latest"),
        "universe": ("Universe", "14", "redroid/redroid:14.0.0-latest"),
        "voyager": ("Voyager", "15", "redroid/redroid:15.0.0-latest")}


def dev_public(d):
    running = d["status"] == "running"
    ready = running and time.time() - d["started"] >= BOOT_SECONDS
    return {"id": d["id"], "name": d["name"], "status": d["status"], "image": PLAT[d["platform"]][2] + " (mock)", "platform": d["platform"],
            "platform_label": PLAT[d["platform"]][0], "android": PLAT[d["platform"]][1],
            "ready": ready, "owner": str(d["owner"]), "created": d["created"],
            "mock": True, "error": "Chế độ mock: thiết bị giả lập, KHÔNG có Android/ADB/WebRTC thật."}


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *a):
        print("%s %s" % (self.command, self.path), "->", a[1] if len(a) > 1 else "")

    # ---- tiện ích
    def send_json(self, data, status=200, headers=None):
        body = json.dumps(data).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def err(self, status, msg):
        self.send_json({"detail": msg}, status)

    def body(self):
        n = int(self.headers.get("Content-Length") or 0)
        try:
            return json.loads(self.rfile.read(n) or b"{}")
        except ValueError:
            return {}

    def cookie(self):
        for part in (self.headers.get("Cookie") or "").split(";"):
            k, _, v = part.strip().partition("=")
            if k == COOKIE:
                return v
        return None

    def user(self):
        h = self.headers.get("Authorization", "")
        if h.startswith("Bearer "):
            uid = SESSIONS.get("access:" + h[7:])
            if uid in USERS:
                return USERS[uid]
        self.err(401, "Chưa đăng nhập.")
        return None

    def issue(self, user):
        access, refresh = secrets.token_urlsafe(24), secrets.token_urlsafe(24)
        SESSIONS["access:" + access] = user["id"]
        SESSIONS[refresh] = user["id"]
        pub = {k: user[k] for k in ("id", "username", "role", "disabled", "created_at")}
        ck = "%s=%s; Path=/api/auth; HttpOnly; SameSite=Strict; Max-Age=604800" % (COOKIE, refresh)
        return {"access_token": access, "token_type": "bearer", "expires_in": 900, "user": pub}, {"Set-Cookie": ck}

    # ---- định tuyến
    def do_GET(self):
        p = self.path.split("?")[0]
        if not p.startswith("/api"):
            return self.static(p)
        if p == "/api/health":
            return self.send_json({"ok": True, "mock": True, "docker": False, "version": "0.6.0-mock", "register": True})
        u = self.user()
        if not u:
            return
        if p == "/api/status":
            return self.send_json({"ok": False, "mock": True, "docker": False, "docker_error": "Đang chạy mock_server.py, không có Docker.",
                                   "adb": False, "adb_detail": "Mock: không có ADB thật.", "webrtc": {},
                                   "problems": ["Đang chạy MOCK (mock_server.py): chỉ để thử giao diện, không có Android/ADB/WebRTC thật."]})
        m = re.fullmatch(r"/api/devices/([a-f0-9]+)/diagnostics", p)
        if m:
            if m.group(1) not in DEVICES:
                return self.err(404, "Device not found.")
            msg = "Chế độ mock: không có Docker, ADB, màn hình hay WebRTC thật."
            return self.send_json({"device": DEVICES[m.group(1)]["name"], "ok": False, "summary": msg,
                                   "steps": [{"id": "mock", "label": "Backend thật", "ok": False, "detail": msg, "ms": 0}],
                                   "stream": {"sessions": 0, "source": None, "input": None}})
        if p == "/api/auth/me":
            return self.send_json({k: u[k] for k in ("id", "username", "role", "disabled", "created_at")})
        if p == "/api/platforms":
            return self.send_json([{"key": k, "label": v[0], "android": v[1], "default": k == "typhoon"} for k, v in PLAT.items()])
        if p == "/api/devices":
            return self.send_json([dev_public(d) for d in DEVICES.values() if u["role"] == "admin" or d["owner"] == u["id"]])
        m = re.fullmatch(r"/api/devices/([a-f0-9]+)", p)
        if m:
            d = DEVICES.get(m.group(1))
            return self.send_json(dev_public(d)) if d else self.err(404, "Device not found.")
        if p == "/api/users":
            if u["role"] != "admin":
                return self.err(403, "Chỉ quản trị viên.")
            return self.send_json([{k: x[k] for k in ("id", "username", "role", "disabled", "created_at")} for x in USERS.values()])
        if p == "/api/audit":
            rows = AUDIT if u["role"] == "admin" else [r for r in AUDIT if r["user"] == u["username"]]
            return self.send_json(rows[:100])
        if p == "/api/webrtc/ice":
            return self.send_json({"iceServers": [{"urls": ["stun:stun.l.google.com:19302"]}], "forceRelay": False})
        if re.fullmatch(r"/api/devices/[a-f0-9]+/screenshot", p):
            return self.err(503, "Chế độ mock: chưa có màn hình thật.")
        self.err(404, "Not found")

    def do_DELETE(self):
        p = self.path.split("?")[0]
        if p == "/api/auth/logout":
            return self.do_POST()
        u = self.user()
        if not u:
            return
        m = re.fullmatch(r"/api/devices/([a-f0-9]+)", p)
        if m:
            d = DEVICES.pop(m.group(1), None)
            if not d:
                return self.err(404, "Device not found.")
            audit(u["username"], "device_delete", d["name"])
            return self.send_json({"deleted": d["id"]})
        m = re.fullmatch(r"/api/users/(\d+)", p)
        if m and u["role"] == "admin":
            uid = int(m.group(1))
            if uid == u["id"]:
                return self.err(400, "Không thể tự xóa chính mình.")
            t = USERS.pop(uid, None)
            if not t:
                return self.err(404, "Không tìm thấy người dùng.")
            audit(u["username"], "user_delete", t["username"])
            return self.send_json({"deleted": uid})
        self.err(404, "Not found")

    def do_POST(self):
        p = self.path.split("?")[0]
        b = self.body() if p != "/api/auth/refresh" else {}
        if p == "/api/auth/login":
            u = next((x for x in USERS.values() if x["username"] == b.get("username") and x["pw"] == b.get("password")), None)
            if not u:
                audit(str(b.get("username", ""))[:64], "login_failed")
                return self.err(401, "Sai tên đăng nhập hoặc mật khẩu.")
            data, hdr = self.issue(u)
            audit(u["username"], "login")
            return self.send_json(data, headers=hdr)
        if p == "/api/auth/register":
            name, pw = str(b.get("username", "")), str(b.get("password", ""))
            if not re.fullmatch(r"[a-zA-Z0-9_.-]{3,32}", name) or len(pw) < 10:
                return self.err(422, "[pattern]")
            if any(x["username"] == name for x in USERS.values()):
                return self.err(409, "Tên đăng nhập đã tồn tại.")
            uid = NEXT_UID[0]; NEXT_UID[0] += 1
            USERS[uid] = {"id": uid, "username": name, "role": "user", "disabled": False,
                          "created_at": int(time.time()), "pw": pw}
            audit(name, "register")
            return self.send_json({"ok": True, "username": name})
        if p == "/api/auth/refresh":
            uid = SESSIONS.pop(self.cookie() or "", None)
            if uid not in USERS:
                return self.err(401, "Chưa đăng nhập.")
            data, hdr = self.issue(USERS[uid])
            return self.send_json(data, headers=hdr)
        if p == "/api/auth/logout":
            SESSIONS.pop(self.cookie() or "", None)
            return self.send_json({"ok": True}, headers={"Set-Cookie": "%s=; Path=/api/auth; Max-Age=0" % COOKIE})
        u = self.user()
        if not u:
            return
        if p == "/api/auth/password":
            if u["pw"] != b.get("current"):
                return self.err(400, "Mật khẩu hiện tại không đúng.")
            if len(b.get("new", "")) < 10:
                return self.err(422, "[min_length]")
            u["pw"] = b["new"]
            audit(u["username"], "password_change")
            return self.send_json({"ok": True})
        if p == "/api/users" and u["role"] == "admin":
            name = b.get("username", "")
            if not re.fullmatch(r"[a-zA-Z0-9_.-]{3,32}", name) or len(b.get("password", "")) < 10:
                return self.err(422, "[pattern]")
            if any(x["username"] == name for x in USERS.values()):
                return self.err(409, "Tên đăng nhập đã tồn tại.")
            uid = NEXT_UID[0]; NEXT_UID[0] += 1
            USERS[uid] = {"id": uid, "username": name, "role": b.get("role", "user"), "disabled": False,
                          "created_at": int(time.time()), "pw": b["password"]}
            audit(u["username"], "user_create", name)
            return self.send_json({"id": uid, "username": name, "role": USERS[uid]["role"]})
        if p == "/api/devices":
            mine = [d for d in DEVICES.values() if d["owner"] == u["id"]]
            if len(DEVICES) >= 1 or (u["role"] != "admin" and len(mine) >= 1):
                return self.err(409, "Đã đạt giới hạn thiết bị (DEVICE_LIMIT=1 trong mock).")
            did = secrets.token_hex(6)
            name = re.sub(r"[^a-zA-Z0-9_-]", "-", b.get("name") or "android-cloud")[:30] or "android-cloud"
            DEVICES[did] = {"id": did, "name": name, "status": "running", "started": time.time(),
                            "owner": u["id"], "platform": b.get("platform") if b.get("platform") in PLAT else "typhoon", "created": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
            audit(u["username"], "device_create", name)
            return self.send_json(dev_public(DEVICES[did]))
        m = re.fullmatch(r"/api/devices/([a-f0-9]+)/(start|stop|restart)", p)
        if m:
            d = DEVICES.get(m.group(1))
            if not d:
                return self.err(404, "Device not found.")
            act = m.group(2)
            d["status"] = "exited" if act == "stop" else "running"
            if act != "stop":
                d["started"] = time.time()
            audit(u["username"], "device_" + act, d["name"])
            return self.send_json(dev_public(d))
        if re.fullmatch(r"/api/devices/[a-f0-9]+/webrtc/offer", p):
            return self.err(503, "Chế độ mock: chưa có luồng WebRTC. Cần backend thật + redroid để xem điện thoại.")
        self.err(404, "Not found")

    def static(self, p):
        p = "/index.html" if p == "/" else p
        f = (FRONT / p.lstrip("/")).resolve()
        if FRONT.resolve() not in f.parents or not f.is_file():
            body = b"Not found"
            self.send_response(404); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
            return
        body = f.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", (mimetypes.guess_type(f.name)[0] or "application/octet-stream") + "; charset=utf-8"
                         if f.suffix in (".html", ".js", ".css") else (mimetypes.guess_type(f.name)[0] or "application/octet-stream"))
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(body)


if __name__ == "__main__":
    print("Mock Shadow Cloud Phone: http://127.0.0.1:%d   (admin / admin12345)" % PORT)
    ThreadingHTTPServer(("127.0.0.1", PORT), H).serve_forever()
