import 'dotenv/config'
import express from 'express'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { Agent } from '@cline/sdk'

const app = express()
const port = Number(process.env.PORT || 3000)
const here = path.dirname(fileURLToPath(import.meta.url))
app.disable('x-powered-by')
app.use(express.json({ limit: '1mb' }))
app.use(express.static(path.join(here, 'public')))

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, configured: Boolean(process.env.OPENAI_API_KEY || process.env.ANTHROPIC_API_KEY || process.env.GOOGLE_API_KEY), provider: process.env.CLINE_PROVIDER || 'openai', model: process.env.CLINE_MODEL || 'gpt-4o-mini' })
})

app.post('/api/chat', async (req, res) => {
  const message = typeof req.body?.message === 'string' ? req.body.message.trim() : ''
  const history = Array.isArray(req.body?.history) ? req.body.history.slice(-12) : []
  if (!message) return res.status(400).json({ error: 'Bạn hãy nhập nội dung trước.' })
  if (message.length > 12000) return res.status(413).json({ error: 'Tin nhắn quá dài (tối đa 12.000 ký tự).' })
  if (!process.env.OPENAI_API_KEY && !process.env.ANTHROPIC_API_KEY && !process.env.GOOGLE_API_KEY) {
    return res.status(503).json({ error: 'Máy chủ chưa cấu hình API key. Hãy thêm khóa của nhà cung cấp AI vào biến môi trường trên máy chủ.' })
  }
  try {
    const agent = new Agent({
      providerId: process.env.CLINE_PROVIDER || 'openai',
      modelId: process.env.CLINE_MODEL || 'gpt-4o-mini',
      systemPrompt: 'You are Cline Mobile, a helpful coding assistant. Answer in the same language as the user. Help explain, write, and debug code. Be clear when you have not actually run or tested code. This web demo has no filesystem or shell tools, so never claim to have modified files or executed commands.',
      tools: []
    })
    const context = history
      .filter(x => x && ['user', 'assistant'].includes(x.role) && typeof x.content === 'string')
      .map(x => `${x.role === 'user' ? 'User' : 'Assistant'}: ${x.content.slice(0, 4000)}`)
      .join('\n\n')
    const prompt = `${context ? `Conversation so far:\n${context}\n\n` : ''}User: ${message}`
    const result = await agent.run(prompt)
    res.json({ text: result?.text || 'AI chưa trả về nội dung.' })
  } catch (err) {
    console.error('Cline SDK error:', err?.message || err)
    res.status(502).json({ error: 'Không kết nối được mô hình AI. Kiểm tra provider, model và API key trong cấu hình máy chủ.' })
  }
})

app.get(/.*/, (_req, res) => res.sendFile(path.join(here, 'public', 'index.html')))
app.listen(port, '0.0.0.0', () => console.log(`Cline Mobile web listening on port ${port}`))
