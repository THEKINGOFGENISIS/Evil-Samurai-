# Cline Mobile Web (Android-friendly starter)

This project was created using the Cline repository you supplied as its base/reference and uses the official `@cline/sdk` package. It provides a mobile-friendly browser chat interface and a Node.js backend.

## Important limitation
The upstream Cline project is a coding agent designed for an IDE, terminal, or desktop environment. A website cannot gain Windows/Linux filesystem and shell access just by converting the UI. This starter gives you a browser chat connected to the Cline SDK, but it intentionally has **no shell or workspace-editing tools** yet. Do not treat it as the full desktop Cline app.

## Run it
Requires Node.js 22+ and a server (for example, a cloud Node hosting service). An Android browser alone cannot run this Node backend.

1. Extract this folder.
2. Run `npm install`.
3. Copy `.env.example` to `.env`.
4. Put your model provider API key in the server-side `.env`; set `CLINE_PROVIDER` and `CLINE_MODEL` to a supported provider/model.
5. Run `npm start` and open `http://localhost:3000` on the same machine. To use it from Android, deploy the project to a Node host and open its HTTPS URL.

Never put provider API keys in `public/index.html`, client JavaScript, or a public Git repository. Set secrets in the hosting provider's environment-variable settings.

## Deploy
Deploy this folder as a Node web service. Build/install command: `npm install`. Start command: `npm start`. Set `OPENAI_API_KEY`, `CLINE_PROVIDER`, and `CLINE_MODEL` as server environment variables. Check `/api/health` after deployment.

## Based on
Cline repository: https://github.com/cline/cline
Cline SDK docs: https://docs.cline.bot/cline-sdk/overview
